package com.example.timedonlinerewards.gui;

import com.example.timedonlinerewards.TimedOnlineRewards;
import com.example.timedonlinerewards.models.RewardPlan;
import com.example.timedonlinerewards.utils.ItemUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

/**
 * 玩家背包物品选择GUI
 */
public class PlayerInventorySelectGui extends BaseGui {
    
    private final RewardPlan plan;
    private final ItemRewardGui parentGui;
    
    public PlayerInventorySelectGui(TimedOnlineRewards plugin, Player player, RewardPlan plan, ItemRewardGui parentGui) {
        super(plugin, player, Bukkit.createInventory(null, 54, "§6选择背包物品"));
        this.plan = plan;
        this.parentGui = parentGui;
        setupInventory();
    }
    
    @Override
    protected void setupInventory() {
        // 清空界面
        inventory.clear();
        
        // 显示玩家背包内容（前36个槽位）
        ItemStack[] playerInventory = player.getInventory().getContents();
        for (int i = 0; i < Math.min(playerInventory.length, 36); i++) {
            ItemStack item = playerInventory[i];
            if (item != null && item.getType() != Material.AIR) {
                inventory.setItem(i, item.clone());
            }
        }
        
        // 说明物品
        ItemStack hint = ItemUtils.createGuiItem(
            Material.PAPER,
            "§e选择说明",
            new String[]{
                "§7点击上方任意物品将其添加到奖励中",
                "§7物品会被复制，不会从你的背包中移除",
                "§7点击下方按钮返回物品奖励设置"
            }
        );
        inventory.setItem(40, hint);
        
        // 返回按钮
        ItemStack backButton = ItemUtils.createGuiItem(
            Material.ARROW,
            "§e返回物品奖励设置",
            "§7返回物品奖励设置界面"
        );
        inventory.setItem(49, backButton);
        
        // 填充空白区域
        ItemStack filler = ItemUtils.createGuiItem(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 36; i < 54; i++) {
            if (inventory.getItem(i) == null) {
                inventory.setItem(i, filler);
            }
        }
    }
    
    @Override
    public void handleInventoryClick(InventoryClickEvent event, Player clickPlayer, ItemStack clickedItem) {
        event.setCancelled(true);
        
        if (clickedItem == null || clickedItem.getType() == Material.AIR) {
            return;
        }
        
        int slot = event.getSlot();
        
        // 背包物品区域（0-35）
        if (slot >= 0 && slot <= 35) {
            if (clickedItem.getType() != Material.AIR) {
                // 添加物品到奖励
                parentGui.addItemToReward(clickedItem);
                clickPlayer.sendMessage(plugin.getConfigManager().getPrefix() + 
                    "§a已添加物品: §e" + (clickedItem.hasItemMeta() && clickedItem.getItemMeta().hasDisplayName() 
                        ? clickedItem.getItemMeta().getDisplayName() 
                        : clickedItem.getType().name()) + " x" + clickedItem.getAmount());
            }
            return;
        }
        
        // 功能按钮
        if (slot == 49) { // 返回按钮
            close();
            parentGui.open();
        }
    }
}