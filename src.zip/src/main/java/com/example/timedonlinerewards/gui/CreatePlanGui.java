package com.example.timedonlinerewards.gui;

import com.example.timedonlinerewards.TimedOnlineRewards;
import com.example.timedonlinerewards.models.RewardPlan;
import com.example.timedonlinerewards.utils.ItemUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

/**
 * 创建奖励计划GUI
 */
public class CreatePlanGui extends BaseGui {
    
    private String pendingPlanName = null;
    private RewardPlan pendingPlan = null;
    
    public CreatePlanGui(TimedOnlineRewards plugin, Player player) {
        super(plugin, player, Bukkit.createInventory(null, 27, "§6创建奖励计划"));
        setupInventory();
    }
    
    @Override
    protected void setupInventory() {
        // 清空界面
        inventory.clear();
        
        // 设置计划名称按钮
        ItemStack nameButton = ItemUtils.createGuiItem(
            Material.NAME_TAG,
            "§a设置计划名称",
            pendingPlanName != null ? 
                new String[]{"§7当前名称: §e" + pendingPlanName, "§7点击修改计划名称"} :
                new String[]{"§7点击在聊天框中输入计划名称"}
        );
        inventory.setItem(10, nameButton);
        
        // 设置时间按钮
        ItemStack timeButton = ItemUtils.createGuiItem(
            Material.CLOCK,
            "§a设置执行时间",
            "§7点击设置奖励发放时间"
        );
        inventory.setItem(12, timeButton);
        
        // 设置奖励内容按钮
        ItemStack rewardButton = ItemUtils.createGuiItem(
            Material.CHEST,
            "§a设置奖励内容",
            "§7点击设置奖励物品和其他奖励"
        );
        inventory.setItem(14, rewardButton);
        
        // 创建按钮
        ItemStack createButton = ItemUtils.createGuiItem(
            Material.EMERALD,
            "§a创建计划",
            "§7点击创建此奖励计划"
        );
        inventory.setItem(16, createButton);
        
        // 返回按钮
        ItemStack backButton = ItemUtils.createGuiItem(
            Material.ARROW,
            "§c返回主界面",
            "§7点击返回主界面"
        );
        inventory.setItem(22, backButton);
        
        // 填充空白区域
        ItemStack filler = ItemUtils.createGuiItem(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 27; i++) {
            if (inventory.getItem(i) == null) {
                inventory.setItem(i, filler);
            }
        }
    }
    
    @Override
    public void handleInventoryClick(InventoryClickEvent event, Player clickPlayer, ItemStack clickedItem) {
        event.setCancelled(true);
        
        if (clickedItem == null || clickedItem.getType() == Material.AIR) {
            return;
        }
        
        int slot = event.getSlot();
        
        switch (slot) {
            case 10: // 设置计划名称
                handleSetPlanName(clickPlayer);
                break;
                
            case 12: // 设置时间
                handleSetTime(clickPlayer);
                break;
                
            case 14: // 设置奖励内容
                handleSetReward(clickPlayer);
                break;
                
            case 16: // 创建计划
                handleCreatePlan(clickPlayer);
                break;
                
            case 22: // 返回主界面
                close();
                new MainGui(plugin, clickPlayer).open();
                break;
        }
    }
    
    /**
     * 处理设置计划名称
     */
    private void handleSetPlanName(Player player) {
        close();
        player.sendMessage(plugin.getConfigManager().getPrefix() + "§a请在聊天框中输入计划名称：");
        
        plugin.getGuiManager().registerChatInputHandler(player, (p, input) -> {
            Bukkit.getScheduler().runTask(plugin, () -> {
                String trimmedInput = input.trim();
                if (trimmedInput.isEmpty()) {
                    p.sendMessage(plugin.getConfigManager().getPrefix() + "§c计划名称不能为空！");
                } else {
                    pendingPlanName = trimmedInput;
                    p.sendMessage(plugin.getConfigManager().getPrefix() + "§a计划名称已设置为: §e" + trimmedInput);
                }
                // 重新打开GUI并保持状态
                CreatePlanGui newGui = new CreatePlanGui(plugin, p);
                newGui.pendingPlanName = CreatePlanGui.this.pendingPlanName;
                newGui.pendingPlan = CreatePlanGui.this.pendingPlan;
                newGui.setupInventory();
                newGui.open();
            });
        });
    }
    
    /**
     * 处理设置时间
     */
    private void handleSetTime(Player player) {
        // 创建临时计划用于时间设置
        if (pendingPlan == null) {
            String tempId = "temp_" + System.currentTimeMillis();
            pendingPlan = new RewardPlan(tempId, pendingPlanName != null ? pendingPlanName : "新奖励计划");
        }
        close();
        new TimeSettingGui(plugin, player, pendingPlan).open();
    }
    
    /**
     * 处理设置奖励内容
     */
    private void handleSetReward(Player player) {
        // 创建临时计划用于奖励设置
        if (pendingPlan == null) {
            String tempId = "temp_" + System.currentTimeMillis();
            pendingPlan = new RewardPlan(tempId, pendingPlanName != null ? pendingPlanName : "新奖励计划");
        }
        close();
        new RewardSettingGui(plugin, player, pendingPlan).open();
    }
    
    /**
     * 处理创建计划
     */
    private void handleCreatePlan(Player player) {
        RewardPlan plan;
        
        if (pendingPlan != null) {
            // 使用已配置的临时计划
            String planId = "plan_" + System.currentTimeMillis();
            pendingPlan.setId(planId);
            if (pendingPlanName != null) {
                pendingPlan.setName(pendingPlanName);
            }
            plan = pendingPlan;
        } else {
            // 创建新的默认计划
            String planId = "plan_" + System.currentTimeMillis();
            String planName = pendingPlanName != null ? pendingPlanName : "新奖励计划";
            
            plan = new RewardPlan(planId, planName);
            
            // 设置默认时间（每日12:00）
            RewardPlan.TimeSettings timeSettings = plan.getTimeSettings();
            timeSettings.setType("daily");
            timeSettings.setHour(12);
            timeSettings.setMinute(0);
            timeSettings.setSecond(0);
        }
        
        // 添加到管理器
        plugin.getRewardManager().addRewardPlan(plan);
        plugin.getRewardManager().saveRewardPlans();
        
        // 重新计算执行时间
        plugin.getScheduleManager().recalculateAllPlans();
        
        close();
        player.sendMessage(plugin.getConfigManager().getPrefix() + "§a已创建奖励计划: §e" + plan.getName());
        player.sendMessage(plugin.getConfigManager().getPrefix() + "§7计划ID: §f" + plan.getId());
        
        // 打开编辑界面
        new EditPlanGui(plugin, player, plan).open();
    }
}