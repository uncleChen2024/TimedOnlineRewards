package com.example.timedonlinerewards.gui;

import com.example.timedonlinerewards.TimedOnlineRewards;
import com.example.timedonlinerewards.models.RewardPlan;
import com.example.timedonlinerewards.utils.ItemUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

/**
 * 编辑奖励计划GUI
 */
public class EditPlanGui extends BaseGui {
    
    private final RewardPlan rewardPlan;
    
    public EditPlanGui(TimedOnlineRewards plugin, Player player, RewardPlan rewardPlan) {
        super(plugin, player, Bukkit.createInventory(null, 45, "§6编辑奖励计划 - " + rewardPlan.getName()));
        this.rewardPlan = rewardPlan;
        setupInventory();
    }
    
    @Override
    protected void setupInventory() {
        // 清空界面
        inventory.clear();
        
        // 计划信息显示
        ItemStack infoItem = ItemUtils.createGuiItem(
            Material.BOOK,
            "§e计划信息",
            new String[]{
                "§7名称: §f" + rewardPlan.getName(),
                "§7ID: §f" + rewardPlan.getId(),
                "§7状态: " + (rewardPlan.isEnabled() ? "§a启用" : "§c禁用"),
                "§7类型: §f" + getTimeTypeDisplay(rewardPlan.getTimeSettings().getType())
            }
        );
        inventory.setItem(4, infoItem);
        
        // 编辑名称按钮
        ItemStack nameButton = ItemUtils.createGuiItem(
            Material.NAME_TAG,
            "§a编辑计划名称",
            new String[]{
                "§7当前名称: §e" + rewardPlan.getName(),
                "§7点击修改计划名称"
            }
        );
        inventory.setItem(10, nameButton);
        
        // 编辑时间按钮
        ItemStack timeButton = ItemUtils.createGuiItem(
            Material.CLOCK,
            "§a编辑执行时间",
            new String[]{
                "§7当前类型: §e" + getTimeTypeDisplay(rewardPlan.getTimeSettings().getType()),
                "§7点击修改执行时间"
            }
        );
        inventory.setItem(12, timeButton);
        
        // 编辑奖励内容按钮
        ItemStack rewardButton = ItemUtils.createGuiItem(
            Material.CHEST,
            "§a编辑奖励内容",
            "§7点击修改奖励物品和其他奖励"
        );
        inventory.setItem(14, rewardButton);
        
        // 切换状态按钮
        Material statusMaterial = rewardPlan.isEnabled() ? Material.REDSTONE : Material.EMERALD;
        String statusText = rewardPlan.isEnabled() ? "§c禁用计划" : "§a启用计划";
        String statusDesc = rewardPlan.isEnabled() ? "§7点击禁用此奖励计划" : "§7点击启用此奖励计划";
        
        ItemStack statusButton = ItemUtils.createGuiItem(
            statusMaterial,
            statusText,
            statusDesc
        );
        inventory.setItem(16, statusButton);
        
        // 删除计划按钮
        ItemStack deleteButton = ItemUtils.createGuiItem(
            Material.BARRIER,
            "§c删除计划",
            new String[]{
                "§7点击删除此奖励计划",
                "§c§l警告: 此操作不可撤销！"
            }
        );
        inventory.setItem(26, deleteButton);
        
        // 保存按钮
        ItemStack saveButton = ItemUtils.createGuiItem(
            Material.EMERALD_BLOCK,
            "§a保存更改",
            "§7点击保存所有更改"
        );
        inventory.setItem(31, saveButton);
        
        // 返回按钮
        ItemStack backButton = ItemUtils.createGuiItem(
            Material.ARROW,
            "§e返回主界面",
            "§7点击返回主界面"
        );
        inventory.setItem(40, backButton);
        
        // 填充空白区域
        ItemStack filler = ItemUtils.createGuiItem(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 45; i++) {
            if (inventory.getItem(i) == null) {
                inventory.setItem(i, filler);
            }
        }
    }
    
    @Override
    public void handleInventoryClick(InventoryClickEvent event, Player clickPlayer, ItemStack clickedItem) {
        event.setCancelled(true);
        
        if (clickedItem == null || clickedItem.getType() == Material.AIR) {
            return;
        }
        
        int slot = event.getSlot();
        
        switch (slot) {
            case 10: // 编辑名称
                handleEditName(clickPlayer);
                break;
                
            case 12: // 编辑时间
                handleEditTime(clickPlayer);
                break;
                
            case 14: // 编辑奖励内容
                handleEditReward(clickPlayer);
                break;
                
            case 16: // 切换状态
                handleToggleStatus(clickPlayer);
                break;
                
            case 26: // 删除计划
                handleDeletePlan(clickPlayer);
                break;
                
            case 31: // 保存更改
                handleSave(clickPlayer);
                break;
                
            case 40: // 返回主界面
                close();
                new MainGui(plugin, clickPlayer).open();
                break;
        }
    }
    
    /**
     * 处理编辑名称
     */
    private void handleEditName(Player player) {
        if (!player.hasPermission("timedrewards.edit")) {
            player.sendMessage(plugin.getConfigManager().getPrefix() + "§c您没有权限编辑奖励计划！");
            return;
        }
        
        close();
        player.sendMessage(plugin.getConfigManager().getPrefix() + "§a请在聊天框中输入新的计划名称：");
        
        plugin.getGuiManager().registerChatInputHandler(player, (p, input) -> {
            Bukkit.getScheduler().runTask(plugin, () -> {
                String trimmedInput = input.trim();
                if (trimmedInput.isEmpty()) {
                    p.sendMessage(plugin.getConfigManager().getPrefix() + "§c计划名称不能为空！");
                } else {
                    rewardPlan.setName(trimmedInput);
                    p.sendMessage(plugin.getConfigManager().getPrefix() + "§a计划名称已修改为: §e" + trimmedInput);
                }
                // 重新打开GUI
                new EditPlanGui(plugin, p, rewardPlan).open();
            });
        });
    }
    
    /**
     * 处理编辑时间
     */
    private void handleEditTime(Player player) {
        if (!player.hasPermission("timedrewards.edit")) {
            player.sendMessage(plugin.getConfigManager().getPrefix() + "§c您没有权限编辑奖励计划！");
            return;
        }
        
        close();
        new TimeSettingGui(plugin, player, rewardPlan).open();
    }
    
    /**
     * 处理编辑奖励内容
     */
    private void handleEditReward(Player player) {
        if (!player.hasPermission("timedrewards.edit")) {
            player.sendMessage(plugin.getConfigManager().getPrefix() + "§c您没有权限编辑奖励计划！");
            return;
        }
        
        close();
        new RewardSettingGui(plugin, player, rewardPlan).open();
    }
    
    /**
     * 处理切换状态
     */
    private void handleToggleStatus(Player player) {
        if (!player.hasPermission("timedrewards.edit")) {
            player.sendMessage(plugin.getConfigManager().getPrefix() + "§c您没有权限编辑奖励计划！");
            return;
        }
        
        rewardPlan.setEnabled(!rewardPlan.isEnabled());
        String status = rewardPlan.isEnabled() ? "启用" : "禁用";
        player.sendMessage(plugin.getConfigManager().getPrefix() + "§a已" + status + "奖励计划: §e" + rewardPlan.getName());
        
        // 刷新界面
        refresh();
    }
    
    /**
     * 处理删除计划
     */
    private void handleDeletePlan(Player player) {
        if (!player.hasPermission("timedrewards.delete")) {
            player.sendMessage(plugin.getConfigManager().getPrefix() + "§c您没有权限删除奖励计划！");
            return;
        }
        
        plugin.getRewardManager().removeRewardPlan(rewardPlan.getId());
        plugin.getRewardManager().saveRewardPlans();
        
        close();
        player.sendMessage(plugin.getConfigManager().getPrefix() + "§a已删除奖励计划: §e" + rewardPlan.getName());
        new MainGui(plugin, player).open();
    }
    
    /**
     * 处理保存更改
     */
    private void handleSave(Player player) {
        if (!player.hasPermission("timedrewards.edit")) {
            player.sendMessage(plugin.getConfigManager().getPrefix() + "§c您没有权限编辑奖励计划！");
            return;
        }
        
        plugin.getRewardManager().saveRewardPlans();
        plugin.getScheduleManager().recalculateAllPlans();
        
        player.sendMessage(plugin.getConfigManager().getPrefix() + "§a奖励计划已保存！");
        
        // 刷新界面
        refresh();
    }
    
    /**
     * 获取时间类型显示名称
     */
    private String getTimeTypeDisplay(String type) {
        switch (type.toLowerCase()) {
            case "daily": return "每日";
            case "weekly": return "每周";
            case "monthly": return "每月";
            case "specific": return "特定时间";
            case "relative": return "相对时间";
            default: return "未知";
        }
    }
}