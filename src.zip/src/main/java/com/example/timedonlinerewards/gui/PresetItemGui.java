package com.example.timedonlinerewards.gui;

import com.example.timedonlinerewards.TimedOnlineRewards;
import com.example.timedonlinerewards.models.RewardPlan;
import com.example.timedonlinerewards.utils.ItemUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

/**
 * 预设物品选择GUI
 */
public class PresetItemGui extends BaseGui {
    
    private final RewardPlan plan;
    private final ItemRewardGui parentGui;
    
    public PresetItemGui(TimedOnlineRewards plugin, Player player, RewardPlan plan, ItemRewardGui parentGui) {
        super(plugin, player, Bukkit.createInventory(null, 54, "§6常用奖励物品"));
        this.plan = plan;
        this.parentGui = parentGui;
        setupInventory();
    }
    
    @Override
    protected void setupInventory() {
        // 清空界面
        inventory.clear();
        
        // 设置常用奖励物品
        setupPresetItems();
        
        // 返回按钮
        ItemStack backButton = ItemUtils.createGuiItem(
            Material.ARROW,
            "§e返回物品奖励设置",
            "§7返回物品奖励设置界面"
        );
        inventory.setItem(49, backButton);
        
        // 填充空白区域
        ItemStack filler = ItemUtils.createGuiItem(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 54; i++) {
            if (inventory.getItem(i) == null) {
                inventory.setItem(i, filler);
            }
        }
    }
    
    /**
     * 设置预设物品
     */
    private void setupPresetItems() {
        // 第一行：贵重物品
        inventory.setItem(0, new ItemStack(Material.DIAMOND, 1));
        inventory.setItem(1, new ItemStack(Material.EMERALD, 5));
        inventory.setItem(2, new ItemStack(Material.GOLD_INGOT, 10));
        inventory.setItem(3, new ItemStack(Material.IRON_INGOT, 20));
        inventory.setItem(4, new ItemStack(Material.NETHERITE_INGOT, 1));
        inventory.setItem(5, new ItemStack(Material.EXPERIENCE_BOTTLE, 10));
        inventory.setItem(6, new ItemStack(Material.ENCHANTED_GOLDEN_APPLE, 1));
        inventory.setItem(7, new ItemStack(Material.GOLDEN_APPLE, 3));
        inventory.setItem(8, new ItemStack(Material.TOTEM_OF_UNDYING, 1));
        
        // 第二行：工具装备
        inventory.setItem(9, new ItemStack(Material.DIAMOND_SWORD, 1));
        inventory.setItem(10, new ItemStack(Material.DIAMOND_PICKAXE, 1));
        inventory.setItem(11, new ItemStack(Material.DIAMOND_AXE, 1));
        inventory.setItem(12, new ItemStack(Material.DIAMOND_SHOVEL, 1));
        inventory.setItem(13, new ItemStack(Material.DIAMOND_HOE, 1));
        inventory.setItem(14, new ItemStack(Material.DIAMOND_HELMET, 1));
        inventory.setItem(15, new ItemStack(Material.DIAMOND_CHESTPLATE, 1));
        inventory.setItem(16, new ItemStack(Material.DIAMOND_LEGGINGS, 1));
        inventory.setItem(17, new ItemStack(Material.DIAMOND_BOOTS, 1));
        
        // 第三行：建筑材料
        inventory.setItem(18, new ItemStack(Material.DIAMOND_BLOCK, 5));
        inventory.setItem(19, new ItemStack(Material.EMERALD_BLOCK, 5));
        inventory.setItem(20, new ItemStack(Material.GOLD_BLOCK, 10));
        inventory.setItem(21, new ItemStack(Material.IRON_BLOCK, 20));
        inventory.setItem(22, new ItemStack(Material.BEACON, 1));
        inventory.setItem(23, new ItemStack(Material.CONDUIT, 1));
        inventory.setItem(24, new ItemStack(Material.SHULKER_BOX, 1));
        inventory.setItem(25, new ItemStack(Material.ENDER_CHEST, 1));
        inventory.setItem(26, new ItemStack(Material.CHEST, 5));
        
        // 第四行：特殊物品
        inventory.setItem(27, new ItemStack(Material.ELYTRA, 1));
        inventory.setItem(28, new ItemStack(Material.TRIDENT, 1));
        inventory.setItem(29, new ItemStack(Material.CROSSBOW, 1));
        inventory.setItem(30, new ItemStack(Material.BOW, 1));
        inventory.setItem(31, new ItemStack(Material.SHIELD, 1));
        inventory.setItem(32, new ItemStack(Material.FIREWORK_ROCKET, 64));
        inventory.setItem(33, new ItemStack(Material.ENDER_PEARL, 16));
        inventory.setItem(34, new ItemStack(Material.BLAZE_ROD, 10));
        inventory.setItem(35, new ItemStack(Material.GHAST_TEAR, 5));
        
        // 说明物品
        ItemStack hint = ItemUtils.createGuiItem(
            Material.PAPER,
            "§e预设物品说明",
            new String[]{
                "§7点击任意物品将其添加到奖励中",
                "§7这些是常用的奖励物品",
                "§7你也可以返回使用自己背包中的物品"
            }
        );
        inventory.setItem(40, hint);
    }
    
    @Override
    public void handleInventoryClick(InventoryClickEvent event, Player clickPlayer, ItemStack clickedItem) {
        event.setCancelled(true);
        
        if (clickedItem == null || clickedItem.getType() == Material.AIR) {
            return;
        }
        
        int slot = event.getSlot();
        
        // 预设物品区域
        if (slot >= 0 && slot <= 35 && clickedItem.getType() != Material.GRAY_STAINED_GLASS_PANE) {
            // 添加物品到奖励
            parentGui.addItemToReward(clickedItem);
            clickPlayer.sendMessage(plugin.getConfigManager().getPrefix() + 
                "§a已添加预设物品: §e" + clickedItem.getType().name() + " x" + clickedItem.getAmount());
            return;
        }
        
        // 功能按钮
        if (slot == 49) { // 返回按钮
            close();
            parentGui.open();
        }
    }
}