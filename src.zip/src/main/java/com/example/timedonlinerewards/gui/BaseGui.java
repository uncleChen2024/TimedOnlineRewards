package com.example.timedonlinerewards.gui;

import com.example.timedonlinerewards.TimedOnlineRewards;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

/**
 * GUI基础类，提供通用的GUI功能
 */
public abstract class BaseGui implements InventoryHolder {
    
    protected final TimedOnlineRewards plugin;
    protected final Player player;
    protected final Inventory inventory;
    
    public BaseGui(TimedOnlineRewards plugin, Player player, Inventory inventory) {
        this.plugin = plugin;
        this.player = player;
        this.inventory = inventory;
    }
    
    /**
     * 打开界面
     */
    public void open() {
        // 注册到GuiManager
        plugin.getGuiManager().registerGui(this);
        player.openInventory(inventory);
    }
    
    /**
     * 关闭界面
     */
    public void close() {
        player.closeInventory();
        plugin.getGuiManager().unregisterGui(player);
    }
    
    /**
     * 子类实现具体的点击处理逻辑
     */
    public abstract void handleInventoryClick(InventoryClickEvent event, Player clickPlayer, ItemStack clickedItem);
    
    /**
     * 刷新界面（子类可重写）
     */
    public void refresh() {
        // 默认实现：重新设置界面内容
        setupInventory();
    }
    
    /**
     * 设置界面内容（子类实现）
     */
    protected abstract void setupInventory();
    
    @Override
    public Inventory getInventory() {
        return inventory;
    }
    
    /**
     * 获取玩家
     */
    public Player getPlayer() {
        return player;
    }
}