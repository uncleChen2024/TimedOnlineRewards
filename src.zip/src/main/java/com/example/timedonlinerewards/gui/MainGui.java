package com.example.timedonlinerewards.gui;

import com.example.timedonlinerewards.TimedOnlineRewards;
import com.example.timedonlinerewards.models.RewardPlan;
import com.example.timedonlinerewards.utils.ItemUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

/**
 * 主GUI界面
 */
public class MainGui extends BaseGui {
    
    public MainGui(TimedOnlineRewards plugin, Player player) {
        super(plugin, player, Bukkit.createInventory(null, 54, "§6定时奖励管理"));
        setupInventory();
    }
    
    @Override
    protected void setupInventory() {
        // 清空界面
        inventory.clear();
        
        // 添加奖励计划
        int slot = 0;
        for (RewardPlan plan : plugin.getRewardManager().getRewardPlans().values()) {
            if (slot >= 45) break; // 最多显示45个计划
            
            List<String> lore = new ArrayList<>();
            lore.add("§7ID: §f" + plan.getId());
            lore.add("§7状态: " + (plan.isEnabled() ? "§a启用" : "§c禁用"));
            lore.add("§7类型: §f" + getTimeTypeDisplay(plan.getTimeSettings().getType()));
            
            if (plan.getNextExecution() > 0) {
                String nextTime = new java.util.Date(plan.getNextExecution() * 1000).toString();
                lore.add("§7下次执行: §f" + nextTime);
            } else {
                lore.add("§7下次执行: §c未设置");
            }
            
            lore.add("");
            lore.add("§e左键点击编辑");
            lore.add("§e右键点击切换状态");
            lore.add("§eShift+右键删除");
            
            Material material = plan.isEnabled() ? Material.EMERALD_BLOCK : Material.REDSTONE_BLOCK;
            ItemStack item = ItemUtils.createGuiItem(material, "§a" + plan.getName(), lore.toArray(new String[0]));
            
            inventory.setItem(slot, item);
            slot++;
        }
        
        // 添加功能按钮
        setupFunctionButtons();
    }
    
    /**
     * 设置功能按钮
     */
    private void setupFunctionButtons() {
        // 创建新计划按钮
        ItemStack createButton = ItemUtils.createGuiItem(
            Material.NETHER_STAR,
            "§a创建新奖励计划",
            "§7点击创建一个新的奖励计划"
        );
        inventory.setItem(49, createButton);
        
        // 重新加载按钮
        ItemStack reloadButton = ItemUtils.createGuiItem(
            Material.COMMAND_BLOCK,
            "§e重新加载配置",
            "§7点击重新加载所有配置文件"
        );
        inventory.setItem(50, reloadButton);
        
        // 关闭按钮
        ItemStack closeButton = ItemUtils.createGuiItem(
            Material.BARRIER,
            "§c关闭界面",
            "§7点击关闭此界面"
        );
        inventory.setItem(53, closeButton);
        
        // 填充空白区域
        ItemStack filler = ItemUtils.createGuiItem(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 45; i < 49; i++) {
            inventory.setItem(i, filler);
        }
        for (int i = 51; i < 53; i++) {
            inventory.setItem(i, filler);
        }
    }
    
    /**
     * 获取时间类型显示名称
     */
    private String getTimeTypeDisplay(String type) {
        switch (type.toLowerCase()) {
            case "daily": return "每日";
            case "weekly": return "每周";
            case "monthly": return "每月";
            case "specific": return "特定时间";
            case "relative": return "相对时间";
            default: return "未知";
        }
    }
    
    @Override
    public void handleInventoryClick(InventoryClickEvent event, Player clickPlayer, ItemStack clickedItem) {
        event.setCancelled(true);
        
        if (clickedItem == null || clickedItem.getType() == Material.AIR) {
            return;
        }
        
        int slot = event.getSlot();
        
        // 处理功能按钮点击
        if (slot == 49) { // 创建新计划
            if (clickPlayer.hasPermission("timedrewards.create")) {
                close();
                new CreatePlanGui(plugin, clickPlayer).open();
            } else {
                clickPlayer.sendMessage(plugin.getConfigManager().getPrefix() + "§c您没有权限创建奖励计划！");
            }
            return;
        }
        
        if (slot == 50) { // 重新加载
            if (clickPlayer.hasPermission("timedrewards.admin")) {
                plugin.getConfigManager().reloadConfigs();
                plugin.getRewardManager().loadRewardPlans();
                plugin.getScheduleManager().recalculateAllPlans();
                refresh();
                clickPlayer.sendMessage(plugin.getConfigManager().getPrefix() + "§a配置已重新加载！");
            } else {
                clickPlayer.sendMessage(plugin.getConfigManager().getPrefix() + "§c您没有权限重新加载配置！");
            }
            return;
        }
        
        if (slot == 53) { // 关闭界面
            close();
            return;
        }
        
        // 处理奖励计划点击
        if (slot < 45) {
            String planId = getPlanIdBySlot(slot);
            if (planId != null) {
                RewardPlan plan = plugin.getRewardManager().getRewardPlan(planId);
                if (plan != null) {
                    if (event.isRightClick() && event.isShiftClick()) {
                        // Shift+右键删除
                        if (clickPlayer.hasPermission("timedrewards.delete")) {
                            plugin.getRewardManager().removeRewardPlan(planId);
                            plugin.getRewardManager().saveRewardPlans();
                            refresh();
                            clickPlayer.sendMessage(plugin.getConfigManager().getPrefix() + "§a已删除奖励计划: §e" + plan.getName());
                        } else {
                            clickPlayer.sendMessage(plugin.getConfigManager().getPrefix() + "§c您没有权限删除奖励计划！");
                        }
                    } else if (event.isRightClick()) {
                        // 右键切换状态
                        if (clickPlayer.hasPermission("timedrewards.edit")) {
                            plan.setEnabled(!plan.isEnabled());
                            plugin.getRewardManager().saveRewardPlans();
                            refresh();
                            String status = plan.isEnabled() ? "启用" : "禁用";
                            clickPlayer.sendMessage(plugin.getConfigManager().getPrefix() + "§a已" + status + "奖励计划: §e" + plan.getName());
                        } else {
                            clickPlayer.sendMessage(plugin.getConfigManager().getPrefix() + "§c您没有权限编辑奖励计划！");
                        }
                    } else {
                        // 左键编辑
                        if (clickPlayer.hasPermission("timedrewards.edit")) {
                            close();
                            new EditPlanGui(plugin, clickPlayer, plan).open();
                        } else {
                            clickPlayer.sendMessage(plugin.getConfigManager().getPrefix() + "§c您没有权限编辑奖励计划！");
                        }
                    }
                }
            }
        }
    }
    
    /**
     * 根据槽位获取计划ID
     */
    private String getPlanIdBySlot(int slot) {
        int index = 0;
        for (String planId : plugin.getRewardManager().getRewardPlans().keySet()) {
            if (index == slot) {
                return planId;
            }
            index++;
        }
        return null;
    }
}