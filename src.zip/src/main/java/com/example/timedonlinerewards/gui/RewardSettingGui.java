package com.example.timedonlinerewards.gui;

import com.example.timedonlinerewards.TimedOnlineRewards;
import com.example.timedonlinerewards.models.RewardPlan;
import com.example.timedonlinerewards.utils.ItemUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

/**
 * 奖励设置GUI
 */
public class RewardSettingGui extends BaseGui {
    
    private final RewardPlan plan;
    
    public RewardSettingGui(TimedOnlineRewards plugin, Player player, RewardPlan plan) {
        super(plugin, player, Bukkit.createInventory(null, 54, "§6奖励设置: " + plan.getName()));
        this.plan = plan;
        setupInventory();
    }
    
    @Override
    protected void setupInventory() {
        // 清空界面
        inventory.clear();
        
        RewardPlan.RewardContent rewards = plan.getRewards();
        
        // 设置奖励类型按钮
        setupRewardTypeButtons(rewards);
        
        // 显示当前奖励内容
        displayCurrentRewards(rewards);
        
        // 功能按钮
        setupFunctionButtons();
        
        // 填充空白区域
        ItemStack filler = ItemUtils.createGuiItem(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 54; i++) {
            if (inventory.getItem(i) == null) {
                inventory.setItem(i, filler);
            }
        }
    }
    
    /**
     * 设置奖励类型按钮
     */
    private void setupRewardTypeButtons(RewardPlan.RewardContent rewards) {
        // 经济奖励设置
        List<String> economyLore = new ArrayList<>();
        economyLore.add("§7当前金额: §e" + rewards.getEconomy());
        economyLore.add("§7点击设置经济奖励");
        ItemStack economyButton = ItemUtils.createGuiItem(Material.GOLD_INGOT, "§e经济奖励", economyLore);
        inventory.setItem(10, economyButton);
        
        // 经验奖励设置
        List<String> expLore = new ArrayList<>();
        expLore.add("§7当前经验: §a" + rewards.getExperience());
        expLore.add("§7点击设置经验奖励");
        ItemStack expButton = ItemUtils.createGuiItem(Material.EXPERIENCE_BOTTLE, "§a经验奖励", expLore);
        inventory.setItem(12, expButton);
        
        // 命令奖励设置
        List<String> commandLore = new ArrayList<>();
        commandLore.add("§7当前命令数: §d" + rewards.getCommands().size());
        commandLore.add("§7点击设置命令奖励");
        ItemStack commandButton = ItemUtils.createGuiItem(Material.COMMAND_BLOCK, "§d命令奖励", commandLore);
        inventory.setItem(14, commandButton);
        
        // 物品奖励设置
        List<String> itemLore = new ArrayList<>();
        itemLore.add("§7当前物品数: §b" + rewards.getItems().size());
        itemLore.add("§7点击设置物品奖励");
        ItemStack itemButton = ItemUtils.createGuiItem(Material.CHEST, "§b物品奖励", itemLore);
        inventory.setItem(16, itemButton);
        
        // 自定义消息设置
        List<String> messageLore = new ArrayList<>();
        String customMsg = plan.getCustomMessage();
        if (customMsg == null || customMsg.trim().isEmpty()) {
            messageLore.add("§7当前消息: §c未设置");
        } else {
            messageLore.add("§7当前消息: §f" + (customMsg.length() > 20 ? customMsg.substring(0, 20) + "..." : customMsg));
        }
        messageLore.add("§7点击设置自定义奖励消息");
        ItemStack messageButton = ItemUtils.createGuiItem(Material.WRITABLE_BOOK, "§6自定义消息", messageLore);
        inventory.setItem(25, messageButton);
    }
    
    /**
     * 显示当前奖励内容
     */
    private void displayCurrentRewards(RewardPlan.RewardContent rewards) {
        // 显示其他奖励信息（不再显示物品奖励，因为有专门的界面）
        if (rewards.getEconomy() > 0) {
            ItemStack economyDisplay = ItemUtils.createGuiItem(
                Material.EMERALD,
                "§e当前经济奖励",
                "§7金额: §f" + rewards.getEconomy()
            );
            inventory.setItem(7, economyDisplay);
        }
        
        if (rewards.getExperience() > 0) {
            ItemStack expDisplay = ItemUtils.createGuiItem(
                Material.EXPERIENCE_BOTTLE,
                "§a当前经验奖励",
                "§7经验值: §f" + rewards.getExperience()
            );
            inventory.setItem(8, expDisplay);
        }
        
        if (!rewards.getCommands().isEmpty()) {
            List<String> commandDisplayLore = new ArrayList<>();
            commandDisplayLore.add("§7命令列表:");
            for (int i = 0; i < Math.min(rewards.getCommands().size(), 5); i++) {
                commandDisplayLore.add("§7- §f" + rewards.getCommands().get(i));
            }
            if (rewards.getCommands().size() > 5) {
                commandDisplayLore.add("§7... 还有 " + (rewards.getCommands().size() - 5) + " 个命令");
            }
            
            ItemStack commandDisplay = ItemUtils.createGuiItem(
                Material.COMMAND_BLOCK,
                "§d当前命令奖励",
                commandDisplayLore
            );
            inventory.setItem(6, commandDisplay);
        }
    }
    
    /**
     * 设置功能按钮
     */
    private void setupFunctionButtons() {
        // 清空物品奖励按钮
        ItemStack clearItemsButton = ItemUtils.createGuiItem(
            Material.BARRIER,
            "§c清空物品奖励",
            "§7点击清空所有物品奖励"
        );
        inventory.setItem(45, clearItemsButton);
        
        // 保存按钮
        ItemStack saveButton = ItemUtils.createGuiItem(
            Material.EMERALD_BLOCK,
            "§a保存设置",
            "§7点击保存奖励设置"
        );
        inventory.setItem(49, saveButton);
        
        // 返回按钮
        ItemStack backButton = ItemUtils.createGuiItem(
            Material.ARROW,
            "§e返回",
            "§7返回编辑界面"
        );
        inventory.setItem(53, backButton);
    }
    
    @Override
    public void handleInventoryClick(InventoryClickEvent event, Player clickPlayer, ItemStack clickedItem) {
        event.setCancelled(true);
        
        if (clickedItem == null || clickedItem.getType() == Material.AIR) {
            return;
        }
        
        int slot = event.getSlot();
        RewardPlan.RewardContent rewards = plan.getRewards();
        
        switch (slot) {
            case 10: // 经济奖励设置
                handleEconomyInput(clickPlayer, rewards);
                break;
                
            case 12: // 经验奖励设置
                handleExperienceInput(clickPlayer, rewards);
                break;
                
            case 14: // 命令奖励设置
                handleCommandInput(clickPlayer, rewards);
                break;
                
            case 16: // 物品奖励设置
                close();
                new ItemRewardGui(plugin, clickPlayer, plan).open();
                break;
                
            case 25: // 自定义消息设置
                handleCustomMessageInput(clickPlayer);
                break;
                
            case 45: // 清空物品奖励
                rewards.getItems().clear();
                refresh();
                showActionBar(clickPlayer, "§a已清空所有物品奖励");
                break;
                
            case 49: // 保存
                handleSavePlan(clickPlayer);
                showActionBar(clickPlayer, "§a奖励设置已保存！");
                break;
                
            case 53: // 返回
                close();
                new EditPlanGui(plugin, clickPlayer, plan).open();
                break;
        }
    }
    
    /**
     * 处理保存计划
     */
    private void handleSavePlan(Player player) {
        // 检查计划是否已经在管理器中
        if (plugin.getRewardManager().getRewardPlan(plan.getId()) == null) {
            // 如果是临时计划，需要先添加到管理器中
            if (plan.getId().startsWith("temp_")) {
                // 生成正式的计划ID
                String newId = "plan_" + System.currentTimeMillis();
                plan.setId(newId);
                
                // 添加到管理器
                plugin.getRewardManager().addRewardPlan(plan);
            } else {
                // 添加到管理器
                plugin.getRewardManager().addRewardPlan(plan);
            }
        }
        
        // 保存配置
        plugin.getRewardManager().saveRewardPlans();
        plugin.getScheduleManager().recalculateAllPlans();
    }
    
    /**
     * 处理经济奖励输入
     */
    private void handleEconomyInput(Player player, RewardPlan.RewardContent rewards) {
        close();
        player.sendMessage(plugin.getConfigManager().getPrefix() + "§a请在聊天框中输入经济奖励金额（输入0表示不给予经济奖励）:");
        
        plugin.getGuiManager().registerChatInputHandler(player, (p, input) -> {
            Bukkit.getScheduler().runTask(plugin, () -> {
                try {
                    double amount = Double.parseDouble(input.trim());
                    if (amount >= 0) {
                        rewards.setEconomy(amount);
                        showActionBar(p, "§a经济奖励已设置为: §e" + amount);
                    } else {
                        showActionBar(p, "§c金额不能为负数！");
                    }
                } catch (NumberFormatException e) {
                    showActionBar(p, "§c请输入有效的数字！");
                }
                // 重新打开GUI
                new RewardSettingGui(plugin, p, plan).open();
            });
        });
    }
    
    /**
     * 处理经验奖励输入
     */
    private void handleExperienceInput(Player player, RewardPlan.RewardContent rewards) {
        close();
        player.sendMessage(plugin.getConfigManager().getPrefix() + "§a请在聊天框中输入经验奖励数量（输入0表示不给予经验奖励）:");
        
        plugin.getGuiManager().registerChatInputHandler(player, (p, input) -> {
            Bukkit.getScheduler().runTask(plugin, () -> {
                try {
                    int amount = Integer.parseInt(input.trim());
                    if (amount >= 0) {
                        rewards.setExperience(amount);
                        showActionBar(p, "§a经验奖励已设置为: §e" + amount);
                    } else {
                        showActionBar(p, "§c经验数量不能为负数！");
                    }
                } catch (NumberFormatException e) {
                    showActionBar(p, "§c请输入有效的整数！");
                }
                // 重新打开GUI
                new RewardSettingGui(plugin, p, plan).open();
            });
        });
    }
    
    /**
     * 处理命令奖励输入
     */
    private void handleCommandInput(Player player, RewardPlan.RewardContent rewards) {
        close();
        player.sendMessage(plugin.getConfigManager().getPrefix() + "§a请在聊天框中输入要执行的命令（不包含/）:");
        player.sendMessage(plugin.getConfigManager().getPrefix() + "§7可用占位符: %player% - 玩家名称");
        player.sendMessage(plugin.getConfigManager().getPrefix() + "§7输入 'clear' 清空所有命令");
        
        plugin.getGuiManager().registerChatInputHandler(player, (p, input) -> {
            Bukkit.getScheduler().runTask(plugin, () -> {
                String command = input.trim();
                if ("clear".equalsIgnoreCase(command)) {
                    rewards.getCommands().clear();
                    showActionBar(p, "§a已清空所有命令奖励");
                } else if (!command.isEmpty()) {
                    rewards.getCommands().add(command);
                    showActionBar(p, "§a已添加命令: §e" + command);
                } else {
                    showActionBar(p, "§c命令不能为空！");
                }
                // 重新打开GUI
                new RewardSettingGui(plugin, p, plan).open();
            });
        });
    }
    
    /**
     * 处理自定义消息输入
     */
    private void handleCustomMessageInput(Player player) {
        close();
        player.sendMessage(plugin.getConfigManager().getPrefix() + "§a请在聊天框中输入自定义奖励消息:");
        player.sendMessage(plugin.getConfigManager().getPrefix() + "§7可用占位符: %player% - 玩家名称, %plan% - 计划名称");
        player.sendMessage(plugin.getConfigManager().getPrefix() + "§7输入 'clear' 清空自定义消息");
        
        plugin.getGuiManager().registerChatInputHandler(player, (p, input) -> {
            Bukkit.getScheduler().runTask(plugin, () -> {
                String message = input.trim();
                if ("clear".equalsIgnoreCase(message)) {
                    plan.setCustomMessage("");
                    showActionBar(p, "§a已清空自定义消息");
                } else if (!message.isEmpty()) {
                    plan.setCustomMessage(message);
                    showActionBar(p, "§a自定义消息已设置");
                } else {
                    showActionBar(p, "§c消息不能为空！");
                }
                // 重新打开GUI
                new RewardSettingGui(plugin, p, plan).open();
            });
        });
    }
    
    /**
    /**
     * 显示ActionBar消息
     */
    private void showActionBar(Player player, String message) {
        // 使用Spigot API发送ActionBar消息
        player.spigot().sendMessage(net.md_5.bungee.api.ChatMessageType.ACTION_BAR, 
            net.md_5.bungee.api.chat.TextComponent.fromLegacyText(message));
    }
}