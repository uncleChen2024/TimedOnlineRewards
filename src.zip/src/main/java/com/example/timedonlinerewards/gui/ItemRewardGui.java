package com.example.timedonlinerewards.gui;

import com.example.timedonlinerewards.TimedOnlineRewards;
import com.example.timedonlinerewards.models.RewardPlan;
import com.example.timedonlinerewards.utils.ItemUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.List;

/**
 * 物品奖励设置GUI
 */
public class ItemRewardGui extends BaseGui {
    
    private final RewardPlan plan;
    
    public ItemRewardGui(TimedOnlineRewards plugin, Player player, RewardPlan plan) {
        super(plugin, player, Bukkit.createInventory(null, 54, "§b物品奖励设置: " + plan.getName()));
        this.plan = plan;
        setupInventory();
    }
    
    @Override
    protected void setupInventory() {
        // 清空界面
        inventory.clear();
        
        // 显示当前物品奖励（前27个槽位）
        displayCurrentItems();
        
        // 设置功能按钮
        setupFunctionButtons();
        
        // 填充空白区域
        ItemStack filler = ItemUtils.createGuiItem(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 27; i < 54; i++) {
            if (inventory.getItem(i) == null) {
                inventory.setItem(i, filler);
            }
        }
    }
    
    /**
     * 显示当前物品奖励
     */
    private void displayCurrentItems() {
        List<ItemStack> items = plan.getRewards().getItems();
        
        // 在前27个槽位显示当前物品
        for (int i = 0; i < Math.min(items.size(), 27); i++) {
            ItemStack item = items.get(i);
            if (item != null && item.getType() != Material.AIR) {
                inventory.setItem(i, item.clone());
            }
        }
    }
    
    /**
     * 设置功能按钮
     */
    private void setupFunctionButtons() {
        // 从背包复制物品按钮
        ItemStack copyFromInventoryButton = ItemUtils.createGuiItem(
            Material.CHEST_MINECART,
            "§a从背包复制物品",
            "§7点击选择背包中的物品"
        );
        inventory.setItem(45, copyFromInventoryButton);
        
        // 预设物品按钮
        ItemStack presetItemsButton = ItemUtils.createGuiItem(
            Material.ITEM_FRAME,
            "§e预设物品",
            "§7点击选择预设物品"
        );
        inventory.setItem(46, presetItemsButton);
        
        // 清空所有物品按钮
        ItemStack clearAllButton = ItemUtils.createGuiItem(
            Material.BARRIER,
            "§c清空所有物品",
            "§7点击清空所有物品奖励"
        );
        inventory.setItem(47, clearAllButton);
        
        // 保存物品奖励按钮
        ItemStack saveButton = ItemUtils.createGuiItem(
            Material.EMERALD_BLOCK,
            "§a保存物品奖励",
            "§7点击保存当前物品设置"
        );
        inventory.setItem(49, saveButton);
        
        // 返回按钮
        ItemStack backButton = ItemUtils.createGuiItem(
            Material.ARROW,
            "§e返回",
            "§7返回奖励设置界面"
        );
        inventory.setItem(53, backButton);
    }
    
    @Override
    public void handleInventoryClick(InventoryClickEvent event, Player clickPlayer, ItemStack clickedItem) {
        int slot = event.getSlot();
        
        // 物品展示区域（0-26）- 只允许查看，不允许修改
        if (slot >= 0 && slot <= 26) {
            event.setCancelled(true);
            return;
        }
        
        // 功能按钮区域
        event.setCancelled(true);
        
        if (clickedItem == null || clickedItem.getType() == Material.AIR) {
            return;
        }
        
        switch (slot) {
            case 45: // 从背包复制物品
                close();
                new PlayerInventorySelectGui(plugin, clickPlayer, plan, this).open();
                break;
                
            case 46: // 预设物品
                close();
                new PresetItemGui(plugin, clickPlayer, plan, this).open();
                break;
                
            case 47: // 清空所有物品
                plan.getRewards().getItems().clear();
                refresh();
                // 延迟显示ActionBar消息，避免被GUI遮盖
                Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    showActionBar(clickPlayer, "§a已清空所有物品奖励");
                }, 3L);
                break;
                
            case 49: // 保存物品奖励
                handleSavePlan(clickPlayer);
                // 延迟显示ActionBar消息，避免被GUI遮盖
                Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    showActionBar(clickPlayer, "§a物品奖励已保存！");
                }, 5L); // 延迟5tick（0.25秒）
                break;
                
            case 53: // 返回
                close();
                new RewardSettingGui(plugin, clickPlayer, plan).open();
                break;
        }
    }
    
    /**
     * 处理保存计划
     */
    private void handleSavePlan(Player player) {
        // 检查计划是否已经在管理器中
        if (plugin.getRewardManager().getRewardPlan(plan.getId()) == null) {
            // 如果是临时计划，需要先添加到管理器中
            if (plan.getId().startsWith("temp_")) {
                // 生成正式的计划ID
                String newId = "plan_" + System.currentTimeMillis();
                plan.setId(newId);
                
                // 添加到管理器
                plugin.getRewardManager().addRewardPlan(plan);
            } else {
                // 添加到管理器
                plugin.getRewardManager().addRewardPlan(plan);
            }
        }
        
        // 保存配置
        plugin.getRewardManager().saveRewardPlans();
        plugin.getScheduleManager().recalculateAllPlans();
    }
    
    /**
     * 显示ActionBar消息
     */
    private void showActionBar(Player player, String message) {
        // 使用Spigot API发送ActionBar消息
        player.spigot().sendMessage(net.md_5.bungee.api.ChatMessageType.ACTION_BAR, 
            net.md_5.bungee.api.chat.TextComponent.fromLegacyText(message));
    }
    
    /**
     * 添加物品到奖励列表
     */
    public void addItemToReward(ItemStack item) {
        if (item != null && item.getType() != Material.AIR) {
            List<ItemStack> items = plan.getRewards().getItems();
            if (items.size() < 27) {
                items.add(item.clone());
                refresh();
            }
        }
    }
}