package com.example.timedonlinerewards.gui;

import com.example.timedonlinerewards.TimedOnlineRewards;
import com.example.timedonlinerewards.models.RewardPlan;
import com.example.timedonlinerewards.utils.ItemUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

/**
 * 时间设置GUI
 */
public class TimeSettingGui extends BaseGui {
    
    private final RewardPlan plan;
    
    public TimeSettingGui(TimedOnlineRewards plugin, Player player, RewardPlan plan) {
        super(plugin, player, Bukkit.createInventory(null, 54, "§6时间设置: " + plan.getName()));
        this.plan = plan;
        setupInventory();
    }
    
    @Override
    protected void setupInventory() {
        // 清空界面
        inventory.clear();
        
        RewardPlan.TimeSettings timeSettings = plan.getTimeSettings();
        
        // 时间类型选择
        setupTimeTypeButtons(timeSettings);
        
        // 时间设置区域
        setupTimeInputs(timeSettings);
        
        // 功能按钮
        setupFunctionButtons();
        
        // 填充空白区域
        ItemStack filler = ItemUtils.createGuiItem(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 54; i++) {
            if (inventory.getItem(i) == null) {
                inventory.setItem(i, filler);
            }
        }
    }
    
    /**
     * 设置时间类型按钮
     */
    private void setupTimeTypeButtons(RewardPlan.TimeSettings timeSettings) {
        String currentType = timeSettings.getType();
        
        // 每日奖励
        Material dailyMaterial = "daily".equals(currentType) ? Material.EMERALD_BLOCK : Material.STONE;
        ItemStack dailyButton = ItemUtils.createGuiItem(
            dailyMaterial,
            "§a每日奖励",
            "daily".equals(currentType) ? "§7当前选择的类型" : "§7点击设置为每日奖励"
        );
        inventory.setItem(10, dailyButton);
        
        // 每周奖励
        Material weeklyMaterial = "weekly".equals(currentType) ? Material.EMERALD_BLOCK : Material.STONE;
        ItemStack weeklyButton = ItemUtils.createGuiItem(
            weeklyMaterial,
            "§b每周奖励",
            "weekly".equals(currentType) ? "§7当前选择的类型" : "§7点击设置为每周奖励"
        );
        inventory.setItem(12, weeklyButton);
        
        // 每月奖励
        Material monthlyMaterial = "monthly".equals(currentType) ? Material.EMERALD_BLOCK : Material.STONE;
        ItemStack monthlyButton = ItemUtils.createGuiItem(
            monthlyMaterial,
            "§d每月奖励",
            "monthly".equals(currentType) ? "§7当前选择的类型" : "§7点击设置为每月奖励"
        );
        inventory.setItem(14, monthlyButton);
    }
    
    /**
     * 设置时间输入区域
     */
    private void setupTimeInputs(RewardPlan.TimeSettings timeSettings) {
        // 小时设置
        List<String> hourLore = new ArrayList<>();
        hourLore.add("§7当前值: §f" + timeSettings.getHour());
        hourLore.add("§7点击修改小时 (0-23)");
        ItemStack hourButton = ItemUtils.createGuiItem(Material.CLOCK, "§e小时设置", hourLore);
        inventory.setItem(28, hourButton);
        
        // 分钟设置
        List<String> minuteLore = new ArrayList<>();
        minuteLore.add("§7当前值: §f" + timeSettings.getMinute());
        minuteLore.add("§7点击修改分钟 (0-59)");
        ItemStack minuteButton = ItemUtils.createGuiItem(Material.REDSTONE_TORCH, "§e分钟设置", minuteLore);
        inventory.setItem(30, minuteButton);
        
        // 秒设置
        List<String> secondLore = new ArrayList<>();
        secondLore.add("§7当前值: §f" + timeSettings.getSecond());
        secondLore.add("§7点击修改秒 (0-59)");
        ItemStack secondButton = ItemUtils.createGuiItem(Material.REPEATER, "§e秒设置", secondLore);
        inventory.setItem(32, secondButton);
        
        // 根据类型显示额外设置
        if ("weekly".equals(timeSettings.getType())) {
            List<String> dayLore = new ArrayList<>();
            dayLore.add("§7当前值: §f星期" + timeSettings.getDayOfWeek());
            dayLore.add("§7点击修改星期几 (1-7)");
            ItemStack dayButton = ItemUtils.createGuiItem(Material.PAPER, "§e星期设置", dayLore);
            inventory.setItem(34, dayButton);
        } else if ("monthly".equals(timeSettings.getType())) {
            List<String> dayLore = new ArrayList<>();
            dayLore.add("§7当前值: §f" + timeSettings.getDayOfMonth() + "日");
            dayLore.add("§7点击修改日期 (1-31)");
            ItemStack dayButton = ItemUtils.createGuiItem(Material.PAPER, "§e日期设置", dayLore);
            inventory.setItem(34, dayButton);
        }
    }
    
    /**
     * 设置功能按钮
     */
    private void setupFunctionButtons() {
        // 保存按钮
        ItemStack saveButton = ItemUtils.createGuiItem(
            Material.EMERALD,
            "§a保存设置",
            "§7点击保存时间设置"
        );
        inventory.setItem(48, saveButton);
        
        // 返回按钮
        ItemStack backButton = ItemUtils.createGuiItem(
            Material.ARROW,
            "§c返回",
            "§7返回编辑界面"
        );
        inventory.setItem(50, backButton);
    }
    
    @Override
    public void handleInventoryClick(InventoryClickEvent event, Player clickPlayer, ItemStack clickedItem) {
        event.setCancelled(true);
        
        if (clickedItem == null || clickedItem.getType() == Material.AIR) {
            return;
        }
        
        int slot = event.getSlot();
        RewardPlan.TimeSettings timeSettings = plan.getTimeSettings();
        
        switch (slot) {
            case 10: // 每日奖励
                timeSettings.setType("daily");
                refresh();
                clickPlayer.sendMessage(plugin.getConfigManager().getPrefix() + "§a已设置为每日奖励");
                break;
                
            case 12: // 每周奖励
                timeSettings.setType("weekly");
                refresh();
                clickPlayer.sendMessage(plugin.getConfigManager().getPrefix() + "§a已设置为每周奖励");
                break;
                
            case 14: // 每月奖励
                timeSettings.setType("monthly");
                refresh();
                clickPlayer.sendMessage(plugin.getConfigManager().getPrefix() + "§a已设置为每月奖励");
                break;
                
            case 28: // 小时设置
                handleTimeInput(clickPlayer, "hour", "小时 (0-23)", 0, 23, timeSettings::setHour);
                break;
                
            case 30: // 分钟设置
                handleTimeInput(clickPlayer, "minute", "分钟 (0-59)", 0, 59, timeSettings::setMinute);
                break;
                
            case 32: // 秒设置
                handleTimeInput(clickPlayer, "second", "秒 (0-59)", 0, 59, timeSettings::setSecond);
                break;
                
            case 34: // 星期/日期设置
                if ("weekly".equals(timeSettings.getType())) {
                    handleTimeInput(clickPlayer, "dayofweek", "星期几 (1-7)", 1, 7, timeSettings::setDayOfWeek);
                } else if ("monthly".equals(timeSettings.getType())) {
                    handleTimeInput(clickPlayer, "dayofmonth", "日期 (1-31)", 1, 31, timeSettings::setDayOfMonth);
                }
                break;
                
            case 48: // 保存
                handleSavePlan(clickPlayer);
                break;
                
            case 50: // 返回
                close();
                new EditPlanGui(plugin, clickPlayer, plan).open();
                break;
        }
    }
    
    /**
     * 处理保存计划
     */
    private void handleSavePlan(Player player) {
        // 检查计划是否已经在管理器中
        if (plugin.getRewardManager().getRewardPlan(plan.getId()) == null) {
            // 如果是临时计划，需要先添加到管理器中
            if (plan.getId().startsWith("temp_")) {
                // 生成正式的计划ID
                String newId = "plan_" + System.currentTimeMillis();
                plan.setId(newId);
                
                // 添加到管理器
                plugin.getRewardManager().addRewardPlan(plan);
                player.sendMessage(plugin.getConfigManager().getPrefix() + "§a已创建奖励计划: §e" + plan.getName());
                player.sendMessage(plugin.getConfigManager().getPrefix() + "§7计划ID: §f" + plan.getId());
            } else {
                // 添加到管理器
                plugin.getRewardManager().addRewardPlan(plan);
            }
        }
        
        // 保存配置
        plugin.getRewardManager().saveRewardPlans();
        plugin.getScheduleManager().recalculateAllPlans();
        player.sendMessage(plugin.getConfigManager().getPrefix() + "§a时间设置已保存！");
    }
    
    /**
     * 处理时间输入
     */
    private void handleTimeInput(Player player, String type, String description, int min, int max, java.util.function.IntConsumer setter) {
        close();
        player.sendMessage(plugin.getConfigManager().getPrefix() + "§a请在聊天框中输入" + description + ":");
        
        plugin.getGuiManager().registerChatInputHandler(player, (p, input) -> {
            Bukkit.getScheduler().runTask(plugin, () -> {
                try {
                    int value = Integer.parseInt(input.trim());
                    if (value >= min && value <= max) {
                        setter.accept(value);
                        p.sendMessage(plugin.getConfigManager().getPrefix() + "§a设置成功！");
                    } else {
                        p.sendMessage(plugin.getConfigManager().getPrefix() + "§c输入值超出范围！请输入 " + min + "-" + max + " 之间的数字");
                    }
                } catch (NumberFormatException e) {
                    p.sendMessage(plugin.getConfigManager().getPrefix() + "§c请输入有效的数字！");
                }
                // 重新打开GUI
                new TimeSettingGui(plugin, p, plan).open();
            });
        });
    }
}