package com.example.timedonlinerewards.gui;

import com.example.timedonlinerewards.TimedOnlineRewards;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * GUI管理器，统一管理所有GUI的事件监听器
 */
public class GuiManager implements Listener {
    
    private final TimedOnlineRewards plugin;
    private final Map<UUID, BaseGui> activeGuis;
    private final Map<UUID, ChatInputHandler> chatInputHandlers;
    
    public GuiManager(TimedOnlineRewards plugin) {
        this.plugin = plugin;
        this.activeGuis = new HashMap<>();
        this.chatInputHandlers = new HashMap<>();
        // 注册事件监听器
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }
    
    /**
     * 注册GUI实例
     */
    public void registerGui(BaseGui gui) {
        activeGuis.put(gui.getPlayer().getUniqueId(), gui);
    }
    
    /**
     * 注销GUI实例
     */
    public void unregisterGui(Player player) {
        activeGuis.remove(player.getUniqueId());
        chatInputHandlers.remove(player.getUniqueId());
    }
    
    /**
     * 获取玩家的活跃GUI
     */
    public BaseGui getActiveGui(Player player) {
        return activeGuis.get(player.getUniqueId());
    }
    
    /**
     * 注册聊天输入处理器
     */
    public void registerChatInputHandler(Player player, ChatInputHandler handler) {
        chatInputHandlers.put(player.getUniqueId(), handler);
    }
    
    /**
     * 移除聊天输入处理器
     */
    public void removeChatInputHandler(Player player) {
        chatInputHandlers.remove(player.getUniqueId());
    }
    
    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) {
            return;
        }
        
        Player player = (Player) event.getWhoClicked();
        BaseGui gui = activeGuis.get(player.getUniqueId());
        
        if (gui != null && event.getInventory().equals(gui.getInventory())) {
            gui.handleInventoryClick(event, player, event.getCurrentItem());
        }
    }
    
    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player)) {
            return;
        }
        
        Player player = (Player) event.getPlayer();
        BaseGui gui = activeGuis.get(player.getUniqueId());
        
        if (gui != null && event.getInventory().equals(gui.getInventory())) {
            // GUI关闭时清理资源
            unregisterGui(player);
        }
    }
    
    @EventHandler
    public void onPlayerChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        ChatInputHandler handler = chatInputHandlers.get(player.getUniqueId());
        
        if (handler != null) {
            event.setCancelled(true);
            handler.handleInput(player, event.getMessage());
            chatInputHandlers.remove(player.getUniqueId());
        }
    }
    
    /**
     * 清理所有GUI
     */
    public void clearAllGuis() {
        activeGuis.clear();
        chatInputHandlers.clear();
    }
    
    /**
     * 获取活跃GUI数量
     */
    public int getActiveGuiCount() {
        return activeGuis.size();
    }
    
    /**
     * 聊天输入处理器接口
     */
    public interface ChatInputHandler {
        void handleInput(Player player, String input);
    }
}