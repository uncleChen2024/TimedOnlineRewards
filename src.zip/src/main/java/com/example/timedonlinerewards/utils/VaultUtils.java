package com.example.timedonlinerewards.utils;

import com.example.timedonlinerewards.TimedOnlineRewards;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.plugin.RegisteredServiceProvider;

/**
 * Vault工具类
 */
public class VaultUtils {
    
    private final TimedOnlineRewards plugin;
    private Economy economy = null;
    
    public VaultUtils(TimedOnlineRewards plugin) {
        this.plugin = plugin;
        boolean economySetup = setupEconomy();
        if (!economySetup) {
            plugin.getLogger().warning("经济系统初始化失败，经济奖励功能将不可用");
        }
    }
    
    /**
     * 设置经济系统
     */
    private boolean setupEconomy() {
        if (plugin.getServer().getPluginManager().getPlugin("Vault") == null) {
            plugin.getLogger().info("未找到Vault插件，经济奖励功能将不可用");
            return false;
        }
        
        RegisteredServiceProvider<Economy> rsp = plugin.getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) {
            plugin.getLogger().info("未找到经济插件，经济奖励功能将不可用");
            return false;
        }
        
        economy = rsp.getProvider();
        plugin.getLogger().info("已连接到经济系统: " + economy.getName());
        return economy != null;
    }
    
    /**
     * 检查是否有经济系统
     */
    public boolean hasEconomy() {
        return economy != null;
    }
    
    /**
     * 获取经济系统实例
     */
    public Economy getEconomy() {
        return economy;
    }
}