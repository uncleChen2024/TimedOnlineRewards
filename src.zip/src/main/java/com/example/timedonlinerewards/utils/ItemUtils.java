package com.example.timedonlinerewards.utils;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 物品工具类
 */
public class ItemUtils {
    
    /**
     * 序列化物品为Map
     */
    public static Map<String, Object> serializeItem(ItemStack item) {
        Map<String, Object> map = new HashMap<>();
        
        map.put("type", item.getType().name());
        map.put("amount", item.getAmount());
        
        if (item.hasItemMeta()) {
            ItemMeta meta = item.getItemMeta();
            
            if (meta != null) {
                if (meta.hasDisplayName()) {
                    map.put("name", meta.getDisplayName());
                }
                
                if (meta.hasLore()) {
                    map.put("lore", meta.getLore());
                }
                
                if (meta.hasCustomModelData()) {
                    map.put("data", meta.getCustomModelData());
                }
            }
        }
        
        return map;
    }
    
    /**
     * 从Map反序列化物品
     */
    public static ItemStack deserializeItem(Map<?, ?> map) {
        try {
            String typeName = (String) map.get("type");
            Material material = Material.valueOf(typeName);
            int amount = (Integer) map.get("amount");
            
            ItemStack item = new ItemStack(material, amount);
            ItemMeta meta = item.getItemMeta();
            
            if (meta != null) {
                if (map.containsKey("name")) {
                    meta.setDisplayName((String) map.get("name"));
                }
                
                if (map.containsKey("lore")) {
                    @SuppressWarnings("unchecked")
                    List<String> lore = (List<String>) map.get("lore");
                    meta.setLore(lore);
                }
                
                if (map.containsKey("data")) {
                    meta.setCustomModelData((Integer) map.get("data"));
                }
                
                item.setItemMeta(meta);
            }
            
            return item;
        } catch (Exception e) {
            return null;
        }
    }
    
    /**
     * 创建GUI物品（完整版本）
     */
    public static ItemStack createGuiItem(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        
        if (meta != null) {
            meta.setDisplayName(name);
            if (lore != null) {
                meta.setLore(lore);
            }
            item.setItemMeta(meta);
        }
        
        return item;
    }
    
    /**
     * 创建GUI物品（单行描述）
     */
    public static ItemStack createGuiItem(Material material, String name, String lore) {
        List<String> loreList = new ArrayList<>();
        if (lore != null && !lore.trim().isEmpty()) {
            loreList.add(lore);
        }
        return createGuiItem(material, name, loreList);
    }
    
    /**
     * 创建GUI物品（无描述）
     */
    public static ItemStack createGuiItem(Material material, String name) {
        return createGuiItem(material, name, (List<String>) null);
    }
    
    /**
     * 创建GUI物品（字符串数组描述）
     */
    public static ItemStack createGuiItem(Material material, String name, String[] lore) {
        List<String> loreList = new ArrayList<>();
        if (lore != null) {
            for (String line : lore) {
                if (line != null) {
                    loreList.add(line);
                }
            }
        }
        return createGuiItem(material, name, loreList);
    }
}