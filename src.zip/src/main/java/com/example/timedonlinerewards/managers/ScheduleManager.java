package com.example.timedonlinerewards.managers;

import com.example.timedonlinerewards.TimedOnlineRewards;
import com.example.timedonlinerewards.models.RewardPlan;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.HashMap;
import java.util.Map;

/**
 * 定时任务管理器
 */
public class ScheduleManager {
    
    private final TimedOnlineRewards plugin;
    private final Map<String, BukkitTask> scheduledTasks;
    private BukkitTask mainTask;
    
    public ScheduleManager(TimedOnlineRewards plugin) {
        this.plugin = plugin;
        this.scheduledTasks = new HashMap<>();
    }
    
    /**
     * 启动定时器
     */
    public void startScheduler() {
        // 主定时任务，每分钟检查一次
        mainTask = new BukkitRunnable() {
            @Override
            public void run() {
                checkRewardPlans();
            }
        }.runTaskTimer(plugin, 20L, 1200L); // 1秒后开始，每60秒执行一次
        
        plugin.getLogger().info("定时任务管理器已启动");
    }
    
    /**
     * 停止定时器
     */
    public void stopScheduler() {
        if (mainTask != null) {
            mainTask.cancel();
        }
        
        for (BukkitTask task : scheduledTasks.values()) {
            task.cancel();
        }
        scheduledTasks.clear();
        
        plugin.getLogger().info("定时任务管理器已停止");
    }
    
    /**
     * 检查奖励计划
     */
    private void checkRewardPlans() {
        long currentTime = System.currentTimeMillis() / 1000; // 转换为Unix时间戳
        
        for (RewardPlan plan : plugin.getRewardManager().getRewardPlans().values()) {
            if (!plan.isEnabled()) {
                continue;
            }
            
            // 如果下次执行时间为0，计算下次执行时间
            if (plan.getNextExecution() == 0) {
                long nextTime = calculateNextExecution(plan);
                plan.setNextExecution(nextTime);
                continue;
            }
            
            // 检查是否到达执行时间
            if (currentTime >= plan.getNextExecution()) {
                executeRewardPlan(plan);
                
                // 计算下次执行时间
                long nextTime = calculateNextExecution(plan);
                plan.setNextExecution(nextTime);
                
                // 保存配置
                plugin.getRewardManager().saveRewardPlans();
            }
        }
    }
    
    /**
     * 执行奖励计划
     */
    private void executeRewardPlan(RewardPlan plan) {
        String prefix = plugin.getConfigManager().getPrefix();
        
        // 处理奖励发放（包括离线处理）
        plugin.getRewardManager().processReward(plan);
        
        // 广播消息
        if (plugin.getConfigManager().getConfig().getBoolean("notifications.enable-broadcast", true)) {
            Bukkit.broadcastMessage(prefix + "§a奖励计划 §e" + plan.getName() + " §a已发放！");
        }
        
        plugin.getLogger().info("已执行奖励计划: " + plan.getName());
    }
    
    /**
     * 计算下次执行时间
     */
    private long calculateNextExecution(RewardPlan plan) {
        RewardPlan.TimeSettings timeSettings = plan.getTimeSettings();
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime nextExecution;
        
        switch (timeSettings.getType().toLowerCase()) {
            case "daily":
                nextExecution = now.withHour(timeSettings.getHour())
                                  .withMinute(timeSettings.getMinute())
                                  .withSecond(timeSettings.getSecond())
                                  .withNano(0);
                
                // 如果今天的时间已过，设置为明天
                if (nextExecution.isBefore(now) || nextExecution.isEqual(now)) {
                    nextExecution = nextExecution.plusDays(1);
                }
                break;
                
            case "weekly":
                nextExecution = now.withHour(timeSettings.getHour())
                                  .withMinute(timeSettings.getMinute())
                                  .withSecond(timeSettings.getSecond())
                                  .withNano(0);
                
                // 调整到指定的星期几
                int currentDayOfWeek = now.getDayOfWeek().getValue();
                int targetDayOfWeek = timeSettings.getDayOfWeek();
                int daysToAdd = targetDayOfWeek - currentDayOfWeek;
                
                if (daysToAdd < 0 || (daysToAdd == 0 && nextExecution.isBefore(now))) {
                    daysToAdd += 7;
                }
                
                nextExecution = nextExecution.plusDays(daysToAdd);
                break;
                
            case "monthly":
                nextExecution = now.withDayOfMonth(timeSettings.getDayOfMonth())
                                  .withHour(timeSettings.getHour())
                                  .withMinute(timeSettings.getMinute())
                                  .withSecond(timeSettings.getSecond())
                                  .withNano(0);
                
                // 如果这个月的时间已过，设置为下个月
                if (nextExecution.isBefore(now) || nextExecution.isEqual(now)) {
                    nextExecution = nextExecution.plusMonths(1);
                }
                break;
                
            case "specific":
                return timeSettings.getSpecificTime();
                
            case "relative":
                return (System.currentTimeMillis() / 1000) + timeSettings.getRelativeTime();
                
            default:
                // 默认为1小时后
                nextExecution = now.plusHours(1);
                break;
        }
        
        return nextExecution.atZone(ZoneId.systemDefault()).toEpochSecond();
    }
    
    /**
     * 重新计算所有奖励计划的下次执行时间
     */
    public void recalculateAllPlans() {
        for (RewardPlan plan : plugin.getRewardManager().getRewardPlans().values()) {
            if (plan.isEnabled()) {
                long nextTime = calculateNextExecution(plan);
                plan.setNextExecution(nextTime);
            }
        }
        plugin.getRewardManager().saveRewardPlans();
    }
}