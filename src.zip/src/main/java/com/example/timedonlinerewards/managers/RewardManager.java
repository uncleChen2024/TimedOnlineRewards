package com.example.timedonlinerewards.managers;

import com.example.timedonlinerewards.TimedOnlineRewards;
import com.example.timedonlinerewards.models.RewardPlan;
import com.example.timedonlinerewards.utils.VaultUtils;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 奖励管理器
 */
public class RewardManager {
    
    private final TimedOnlineRewards plugin;
    private final Map<String, RewardPlan> rewardPlans;
    private File rewardsFile;
    private FileConfiguration rewardsConfig;
    
    public RewardManager(TimedOnlineRewards plugin) {
        this.plugin = plugin;
        this.rewardPlans = new ConcurrentHashMap<>();
        initializeRewardsFile();
        loadRewardPlans();
    }
    
    /**
     * 初始化奖励配置文件
     */
    private void initializeRewardsFile() {
        rewardsFile = new File(plugin.getDataFolder(), "rewards.yml");
        if (!rewardsFile.exists()) {
            plugin.saveResource("rewards.yml", false);
        }
        rewardsConfig = YamlConfiguration.loadConfiguration(rewardsFile);
    }
    
    /**
     * 加载奖励计划
     */
    public void loadRewardPlans() {
        rewardPlans.clear();
        
        ConfigurationSection plansSection = rewardsConfig.getConfigurationSection("plans");
        if (plansSection == null) {
            plugin.getLogger().info("没有找到奖励计划配置");
            return;
        }
        
        for (String planId : plansSection.getKeys(false)) {
            ConfigurationSection planSection = plansSection.getConfigurationSection(planId);
            if (planSection == null) continue;
            
            RewardPlan plan = new RewardPlan(planId, planSection.getString("name", planId));
            
            // 加载基本信息
            plan.setEnabled(planSection.getBoolean("enabled", true));
            plan.setCustomMessage(planSection.getString("customMessage", ""));
            plan.setNextExecution(planSection.getLong("nextExecution", 0));
            
            // 加载时间设置
            ConfigurationSection timeSection = planSection.getConfigurationSection("timeSettings");
            if (timeSection != null) {
                RewardPlan.TimeSettings timeSettings = plan.getTimeSettings();
                timeSettings.setType(timeSection.getString("type", "daily"));
                timeSettings.setHour(timeSection.getInt("hour", 12));
                timeSettings.setMinute(timeSection.getInt("minute", 0));
                timeSettings.setSecond(timeSection.getInt("second", 0));
                timeSettings.setDayOfWeek(timeSection.getInt("dayOfWeek", 1));
                timeSettings.setDayOfMonth(timeSection.getInt("dayOfMonth", 1));
                timeSettings.setSpecificTime(timeSection.getLong("specificTime", 0));
                timeSettings.setRelativeTime(timeSection.getLong("relativeTime", 0));
            }
            
            // 加载奖励内容
            ConfigurationSection rewardsSection = planSection.getConfigurationSection("rewards");
            if (rewardsSection != null) {
                RewardPlan.RewardContent rewards = plan.getRewards();
                
                // 加载物品奖励
                List<?> itemsList = rewardsSection.getList("items");
                if (itemsList != null) {
                    List<ItemStack> items = new ArrayList<>();
                    for (Object obj : itemsList) {
                        if (obj instanceof ItemStack) {
                            items.add((ItemStack) obj);
                        }
                    }
                    rewards.setItems(items);
                }
                
                // 加载其他奖励
                rewards.setEconomy(rewardsSection.getDouble("economy", 0.0));
                rewards.setExperience(rewardsSection.getInt("experience", 0));
                rewards.setCommands(rewardsSection.getStringList("commands"));
            }
            
            rewardPlans.put(planId, plan);
        }
        
        plugin.getLogger().info("已加载 " + rewardPlans.size() + " 个奖励计划");
    }
    
    /**
     * 保存奖励计划
     */
    public void saveRewardPlans() {
        // 清空现有配置
        rewardsConfig.set("plans", null);
        
        for (RewardPlan plan : rewardPlans.values()) {
            String path = "plans." + plan.getId();
            
            // 保存基本信息
            rewardsConfig.set(path + ".name", plan.getName());
            rewardsConfig.set(path + ".enabled", plan.isEnabled());
            rewardsConfig.set(path + ".customMessage", plan.getCustomMessage());
            rewardsConfig.set(path + ".nextExecution", plan.getNextExecution());
            
            // 保存时间设置
            RewardPlan.TimeSettings timeSettings = plan.getTimeSettings();
            rewardsConfig.set(path + ".timeSettings.type", timeSettings.getType());
            rewardsConfig.set(path + ".timeSettings.hour", timeSettings.getHour());
            rewardsConfig.set(path + ".timeSettings.minute", timeSettings.getMinute());
            rewardsConfig.set(path + ".timeSettings.second", timeSettings.getSecond());
            rewardsConfig.set(path + ".timeSettings.dayOfWeek", timeSettings.getDayOfWeek());
            rewardsConfig.set(path + ".timeSettings.dayOfMonth", timeSettings.getDayOfMonth());
            rewardsConfig.set(path + ".timeSettings.specificTime", timeSettings.getSpecificTime());
            rewardsConfig.set(path + ".timeSettings.relativeTime", timeSettings.getRelativeTime());
            
            // 保存奖励内容
            RewardPlan.RewardContent rewards = plan.getRewards();
            rewardsConfig.set(path + ".rewards.items", rewards.getItems());
            rewardsConfig.set(path + ".rewards.economy", rewards.getEconomy());
            rewardsConfig.set(path + ".rewards.experience", rewards.getExperience());
            rewardsConfig.set(path + ".rewards.commands", rewards.getCommands());
        }
        
        try {
            rewardsConfig.save(rewardsFile);
            plugin.getLogger().info("奖励计划已保存");
        } catch (IOException e) {
            plugin.getLogger().severe("保存奖励计划时出错: " + e.getMessage());
        }
    }
    
    /**
     * 添加奖励计划
     */
    public void addRewardPlan(RewardPlan plan) {
        rewardPlans.put(plan.getId(), plan);
    }
    
    /**
     * 移除奖励计划
     */
    public void removeRewardPlan(String planId) {
        rewardPlans.remove(planId);
    }
    
    /**
     * 获取奖励计划
     */
    public RewardPlan getRewardPlan(String planId) {
        return rewardPlans.get(planId);
    }
    
    /**
     * 获取所有奖励计划
     */
    public Collection<RewardPlan> getAllRewardPlans() {
        return rewardPlans.values();
    }
    
    /**
     * 获取奖励计划Map
     */
    public Map<String, RewardPlan> getRewardPlans() {
        return rewardPlans;
    }
    
    /**
     * 处理奖励发放（包括离线玩家处理）
     */
    public void processReward(RewardPlan plan) {
        // 给所有在线玩家发放奖励
        for (Player player : Bukkit.getOnlinePlayers()) {
            giveReward(player, plan);
        }
        
        // 处理离线玩家奖励
        String offlineHandling = plugin.getConfigManager().getOfflineHandling();
        if (!"skip".equals(offlineHandling)) {
            // 为了演示，这里我们可以为特定的离线玩家存储奖励
            // 在实际应用中，您可能需要维护一个应该接收奖励的玩家列表
            
            // 获取服务器上所有曾经登录过的玩家（通过playerdata文件夹）
            java.io.File playerDataDir = new java.io.File(Bukkit.getWorldContainer(), "world/playerdata");
            if (playerDataDir.exists() && playerDataDir.isDirectory()) {
                java.io.File[] playerFiles = playerDataDir.listFiles((dir, name) -> name.endsWith(".dat"));
                if (playerFiles != null) {
                    for (java.io.File playerFile : playerFiles) {
                        String fileName = playerFile.getName();
                        String uuidString = fileName.substring(0, fileName.length() - 4); // 移除.dat扩展名
                        
                        try {
                            java.util.UUID playerUUID = java.util.UUID.fromString(uuidString);
                            
                            // 检查玩家是否在线
                            Player onlinePlayer = Bukkit.getPlayer(playerUUID);
                            if (onlinePlayer == null) {
                                // 玩家离线，存储奖励
                                org.bukkit.OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer(playerUUID);
                                String playerName = offlinePlayer.getName();
                                if (playerName != null) {
                                    plugin.getOfflineRewardManager().storeOfflineReward(playerUUID, playerName, plan);
                                }
                            }
                        } catch (IllegalArgumentException e) {
                            // 无效的UUID，跳过
                            continue;
                        }
                    }
                }
            }
            
            plugin.getLogger().info("奖励计划 " + plan.getName() + " 已执行，离线奖励已存储");
        }
    }
    
    /**
     * 给予玩家奖励
     */
    public void giveReward(Player player, RewardPlan plan) {
        if (player == null || plan == null) {
            return;
        }
        
        RewardPlan.RewardContent rewards = plan.getRewards();
        List<String> rewardDetails = new ArrayList<>();
        
        // 给予物品奖励
        if (!rewards.getItems().isEmpty()) {
            for (ItemStack item : rewards.getItems()) {
                if (item != null && item.getType() != org.bukkit.Material.AIR) {
                    // 检查背包空间
                    if (player.getInventory().firstEmpty() != -1) {
                        player.getInventory().addItem(item.clone());
                    } else {
                        // 背包满了，掉落到地上
                        player.getWorld().dropItemNaturally(player.getLocation(), item.clone());
                    }
                }
            }
            rewardDetails.add("§b物品 x" + rewards.getItems().size());
        }
        
        // 给予经济奖励
        if (rewards.getEconomy() > 0) {
            VaultUtils vaultUtils = new VaultUtils(plugin);
            if (vaultUtils.hasEconomy()) {
                vaultUtils.getEconomy().depositPlayer(player, rewards.getEconomy());
                rewardDetails.add("§e金币 " + rewards.getEconomy());
            }
        }
        
        // 给予经验奖励
        if (rewards.getExperience() > 0) {
            player.giveExp(rewards.getExperience());
            rewardDetails.add("§a经验 " + rewards.getExperience());
        }
        
        // 执行命令奖励
        if (!rewards.getCommands().isEmpty()) {
            for (String command : rewards.getCommands()) {
                String processedCommand = command.replace("%player%", player.getName());
                Bukkit.getScheduler().runTask(plugin, () -> {
                    Bukkit.dispatchCommand(Bukkit.getConsoleSender(), processedCommand);
                });
            }
            rewardDetails.add("§d特殊奖励 x" + rewards.getCommands().size());
        }
        
        // 发送奖励通知
        String prefix = plugin.getConfigManager().getPrefix();
        player.sendMessage(prefix + "§a您获得了定时奖励: §e" + plan.getName());
        
        // 显示详细奖励内容
        if (!rewardDetails.isEmpty()) {
            String detailsText = String.join("§7, ", rewardDetails);
            player.sendMessage(prefix + "§7奖励内容: " + detailsText);
        }
        
        // 显示自定义消息
        String customMessage = plan.getCustomMessage();
        if (customMessage != null && !customMessage.trim().isEmpty()) {
            String processedMessage = customMessage
                .replace("%player%", player.getName())
                .replace("%plan%", plan.getName());
            player.sendMessage(prefix + processedMessage);
        }
        
        plugin.getLogger().info("已给予玩家 " + player.getName() + " 奖励计划: " + plan.getName());
    }
}