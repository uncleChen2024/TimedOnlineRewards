package com.example.timedonlinerewards.managers;

import com.example.timedonlinerewards.TimedOnlineRewards;
import com.example.timedonlinerewards.models.RewardPlan;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * 离线奖励管理器
 * 负责处理玩家离线时的奖励存储和发放
 */
public class OfflineRewardManager {
    
    private final TimedOnlineRewards plugin;
    private final File offlineRewardsDir;
    
    public OfflineRewardManager(TimedOnlineRewards plugin) {
        this.plugin = plugin;
        this.offlineRewardsDir = new File(plugin.getDataFolder(), "offline-rewards");
        
        // 创建离线奖励目录
        if (!offlineRewardsDir.exists()) {
            boolean created = offlineRewardsDir.mkdirs();
            if (!created) {
                plugin.getLogger().warning("无法创建离线奖励目录");
            }
        }
    }
    
    /**
     * 为离线玩家存储奖励
     */
    public void storeOfflineReward(UUID playerUUID, String playerName, RewardPlan plan) {
        String offlineHandling = plugin.getConfigManager().getOfflineHandling();
        
        // 如果配置为跳过离线奖励，直接返回
        if ("skip".equals(offlineHandling)) {
            plugin.getLogger().info("玩家 " + playerName + " 离线，跳过奖励: " + plan.getName());
            return;
        }
        
        // 保存离线奖励到文件
        File playerFile = new File(offlineRewardsDir, playerUUID.toString() + ".yml");
        FileConfiguration config = YamlConfiguration.loadConfiguration(playerFile);
        
        // 获取当前离线奖励列表
        List<String> offlineRewards = config.getStringList("rewards");
        
        // 添加新的离线奖励记录
        String rewardRecord = plan.getId() + ":" + System.currentTimeMillis() + ":" + plan.getName();
        offlineRewards.add(rewardRecord);
        
        // 保存到配置文件
        config.set("player-name", playerName);
        config.set("rewards", offlineRewards);
        
        try {
            config.save(playerFile);
            plugin.getLogger().info("已为离线玩家 " + playerName + " 保存奖励: " + plan.getName());
        } catch (IOException e) {
            plugin.getLogger().severe("保存离线奖励时出错: " + e.getMessage());
        }
    }
    
    /**
     * 检查玩家是否有待领取的离线奖励
     */
    public boolean hasOfflineRewards(UUID playerUUID) {
        File playerFile = new File(offlineRewardsDir, playerUUID.toString() + ".yml");
        if (!playerFile.exists()) {
            return false;
        }
        
        FileConfiguration config = YamlConfiguration.loadConfiguration(playerFile);
        List<String> rewards = config.getStringList("rewards");
        return !rewards.isEmpty();
    }
    
    /**
     * 获取玩家的离线奖励数量
     */
    public int getOfflineRewardCount(UUID playerUUID) {
        File playerFile = new File(offlineRewardsDir, playerUUID.toString() + ".yml");
        if (!playerFile.exists()) {
            return 0;
        }
        
        FileConfiguration config = YamlConfiguration.loadConfiguration(playerFile);
        List<String> rewards = config.getStringList("rewards");
        return rewards.size();
    }
    
    /**
     * 处理玩家上线时的离线奖励
     */
    public void processOfflineRewards(Player player) {
        UUID playerUUID = player.getUniqueId();
        File playerFile = new File(offlineRewardsDir, playerUUID.toString() + ".yml");
        
        if (!playerFile.exists()) {
            return; // 没有离线奖励
        }
        
        FileConfiguration config = YamlConfiguration.loadConfiguration(playerFile);
        List<String> rewards = config.getStringList("rewards");
        
        if (rewards.isEmpty()) {
            return; // 没有待处理的奖励
        }
        
        String offlineHandling = plugin.getConfigManager().getOfflineHandling();
        
        if ("keep".equals(offlineHandling)) {
            // 保留模式：提示玩家有待领取的奖励
            int count = rewards.size();
            
            // 使用配置中的自定义消息
            String welcomeMsg = plugin.getConfigManager().getOfflineWelcomeMessage()
                .replace("%count%", String.valueOf(count));
            String hintMsg = plugin.getConfigManager().getOfflineHintMessage();
            
            // 转换颜色代码并发送消息
            player.sendMessage(plugin.getConfigManager().getPrefix() + 
                org.bukkit.ChatColor.translateAlternateColorCodes('&', welcomeMsg));
            player.sendMessage(plugin.getConfigManager().getPrefix() + 
                org.bukkit.ChatColor.translateAlternateColorCodes('&', hintMsg));
                
        } else if ("delay".equals(offlineHandling)) {
            // 延迟模式：立即发放所有离线奖励
            int totalCount = rewards.size();
            
            // 使用配置中的自定义消息
            String delayMsg = plugin.getConfigManager().getOfflineDelayMessage()
                .replace("%count%", String.valueOf(totalCount));
            
            player.sendMessage(plugin.getConfigManager().getPrefix() + 
                org.bukkit.ChatColor.translateAlternateColorCodes('&', delayMsg));
            
            int successCount = 0;
            for (String rewardRecord : rewards) {
                String[] parts = rewardRecord.split(":");
                if (parts.length >= 3) {
                    String planId = parts[0];
                    String planName = parts[2];
                    
                    // 获取奖励计划并发放奖励
                    RewardPlan plan = plugin.getRewardManager().getRewardPlan(planId);
                    if (plan != null) {
                        plugin.getRewardManager().giveReward(player, plan);
                        successCount++;
                    } else {
                        plugin.getLogger().warning("找不到奖励计划: " + planId);
                    }
                }
            }
            
            // 使用配置中的成功消息
            String successMsg = plugin.getConfigManager().getOfflineDelaySuccessMessage()
                .replace("%count%", String.valueOf(successCount));
            
            player.sendMessage(plugin.getConfigManager().getPrefix() + 
                org.bukkit.ChatColor.translateAlternateColorCodes('&', successMsg));
            
            // 清空已发放的离线奖励
            clearOfflineRewards(playerUUID);
        }
    }
    
    /**
    /**
     * 移除特定的离线奖励记录
     */
    public void removeOfflineReward(UUID playerUUID, String planId, long timestamp) {
        File playerFile = new File(offlineRewardsDir, playerUUID.toString() + ".yml");
        if (!playerFile.exists()) {
            return;
        }
        
        FileConfiguration config = YamlConfiguration.loadConfiguration(playerFile);
        List<String> rewards = config.getStringList("rewards");
        
        // 查找并移除匹配的奖励记录
        String targetRecord = planId + ":" + timestamp;
        rewards.removeIf(record -> record.startsWith(targetRecord));
        
        // 保存更新后的配置
        config.set("rewards", rewards);
        
        try {
            config.save(playerFile);
            
            // 如果没有剩余奖励，删除文件
            if (rewards.isEmpty()) {
                boolean deleted = playerFile.delete();
                if (!deleted) {
                    plugin.getLogger().warning("无法删除空的离线奖励文件: " + playerFile.getName());
                }
            }
        } catch (IOException e) {
            plugin.getLogger().severe("保存离线奖励文件时出错: " + e.getMessage());
        }
    }
    
    /**
     * 清空玩家的离线奖励记录
     */
    public void clearOfflineRewards(UUID playerUUID) {
        File playerFile = new File(offlineRewardsDir, playerUUID.toString() + ".yml");
        if (playerFile.exists()) {
            boolean deleted = playerFile.delete();
            if (!deleted) {
                plugin.getLogger().warning("无法删除离线奖励文件: " + playerFile.getName());
            }
        }
    }
    
    /**
     * 获取玩家的离线奖励详情
     */
    public List<OfflineRewardInfo> getOfflineRewardDetails(UUID playerUUID) {
        List<OfflineRewardInfo> details = new ArrayList<>();
        File playerFile = new File(offlineRewardsDir, playerUUID.toString() + ".yml");
        
        if (!playerFile.exists()) {
            return details;
        }
        
        FileConfiguration config = YamlConfiguration.loadConfiguration(playerFile);
        List<String> rewards = config.getStringList("rewards");
        
        for (String rewardRecord : rewards) {
            String[] parts = rewardRecord.split(":");
            if (parts.length >= 3) {
                String planId = parts[0];
                long timestamp = Long.parseLong(parts[1]);
                String planName = parts[2];
                
                details.add(new OfflineRewardInfo(planId, planName, timestamp));
            }
        }
        
        return details;
    }
    
    /**
     * 离线奖励信息类
     */
    public static class OfflineRewardInfo {
        private final String planId;
        private final String planName;
        private final long timestamp;
        
        public OfflineRewardInfo(String planId, String planName, long timestamp) {
            this.planId = planId;
            this.planName = planName;
            this.timestamp = timestamp;
        }
        
        public String getPlanId() { return planId; }
        public String getPlanName() { return planName; }
        public long getTimestamp() { return timestamp; }
    }
}