package com.example.timedonlinerewards.commands;

import com.example.timedonlinerewards.TimedOnlineRewards;
import com.example.timedonlinerewards.gui.MainGui;
import com.example.timedonlinerewards.models.RewardPlan;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 主命令处理器
 */
public class TimedRewardsCommand implements CommandExecutor, TabCompleter {
    
    private final TimedOnlineRewards plugin;
    
    public TimedRewardsCommand(TimedOnlineRewards plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String prefix = plugin.getConfigManager().getPrefix();
        
        if (args.length == 0) {
            if (sender instanceof Player) {
                Player player = (Player) sender;
                if (player.hasPermission("timedrewards.admin")) {
                    new MainGui(plugin, player).open();
                    return true;
                } else {
                    player.sendMessage(prefix + "§c您没有权限使用此命令！");
                    return true;
                }
            } else {
                sender.sendMessage(prefix + "§c此命令只能由玩家执行！");
                return true;
            }
        }
        
        String subCommand = args[0].toLowerCase();
        
        switch (subCommand) {
            case "list":
                return handleListCommand(sender);
                
            case "toggle":
                return handleToggleCommand(sender, args);
                
            case "reload":
                return handleReloadCommand(sender);
                
            case "offline":
                return handleOfflineCommand(sender, args);
                
            case "help":
                return handleHelpCommand(sender);
                
            default:
                sender.sendMessage(prefix + "§c未知的子命令！使用 /tr help 查看帮助");
                return true;
        }
    }
    
    /**
     * 处理list命令
     */
    private boolean handleListCommand(CommandSender sender) {
        String prefix = plugin.getConfigManager().getPrefix();
        
        if (!sender.hasPermission("timedrewards.list")) {
            sender.sendMessage(prefix + "§c您没有权限使用此命令！");
            return true;
        }
        
        sender.sendMessage(prefix + "§a奖励计划列表：");
        
        for (RewardPlan plan : plugin.getRewardManager().getRewardPlans().values()) {
            String status = plan.isEnabled() ? "§a启用" : "§c禁用";
            String nextTime = plan.getNextExecution() > 0 ? 
                new java.util.Date(plan.getNextExecution() * 1000).toString() : "未设置";
            
            sender.sendMessage("§7- §e" + plan.getName() + " §7(" + plan.getId() + ") " + status);
            sender.sendMessage("  §7下次执行: §f" + nextTime);
        }
        
        return true;
    }
    
    /**
     * 处理toggle命令
     */
    private boolean handleToggleCommand(CommandSender sender, String[] args) {
        String prefix = plugin.getConfigManager().getPrefix();
        
        if (!sender.hasPermission("timedrewards.edit")) {
            sender.sendMessage(prefix + "§c您没有权限使用此命令！");
            return true;
        }
        
        if (args.length < 2) {
            sender.sendMessage(prefix + "§c用法: /tr toggle <计划ID>");
            return true;
        }
        
        String planId = args[1];
        RewardPlan plan = plugin.getRewardManager().getRewardPlan(planId);
        
        if (plan == null) {
            sender.sendMessage(prefix + "§c找不到ID为 " + planId + " 的奖励计划！");
            return true;
        }
        
        plan.setEnabled(!plan.isEnabled());
        plugin.getRewardManager().saveRewardPlans();
        
        String status = plan.isEnabled() ? "启用" : "禁用";
        sender.sendMessage(prefix + "§a已" + status + "奖励计划: §e" + plan.getName());
        
        return true;
    }
    
    /**
     * 处理reload命令
     */
    private boolean handleReloadCommand(CommandSender sender) {
        String prefix = plugin.getConfigManager().getPrefix();
        
        if (!sender.hasPermission("timedrewards.admin")) {
            sender.sendMessage(prefix + "§c您没有权限使用此命令！");
            return true;
        }
        
        plugin.getConfigManager().reloadConfigs();
        plugin.getRewardManager().loadRewardPlans();
        plugin.getScheduleManager().recalculateAllPlans();
        
        sender.sendMessage(prefix + "§a配置文件已重新加载！");
        return true;
    }
    
    /**
     * 处理offline命令
     */
    private boolean handleOfflineCommand(CommandSender sender, String[] args) {
        String prefix = plugin.getConfigManager().getPrefix();
        
        if (!(sender instanceof Player)) {
            sender.sendMessage(prefix + "§c此命令只能由玩家执行！");
            return true;
        }
        
        Player player = (Player) sender;
        
        if (!player.hasPermission("timedrewards.offline")) {
            player.sendMessage(prefix + "§c您没有权限使用此命令！");
            return true;
        }
        
        if (args.length == 1) {
            // /tr offline - 显示离线奖励概览
            return showOfflineRewardOverview(player);
        }
        
        String subCmd = args[1].toLowerCase();
        switch (subCmd) {
            case "list":
                return showOfflineRewardList(player);
                
            case "claim":
                if (args.length >= 3 && "all".equals(args[2])) {
                    return claimAllOfflineRewards(player);
                } else {
                    return claimNextOfflineReward(player);
                }
                
            case "clear":
                return clearOfflineRewards(player);
                
            default:
                player.sendMessage(prefix + "§c用法: /tr offline [list|claim|clear]");
                return true;
        }
    }
    
    /**
     * 显示离线奖励概览
     */
    private boolean showOfflineRewardOverview(Player player) {
        String prefix = plugin.getConfigManager().getPrefix();
        int count = plugin.getOfflineRewardManager().getOfflineRewardCount(player.getUniqueId());
        
        if (count == 0) {
            player.sendMessage(prefix + "§7您当前没有待领取的离线奖励");
        } else {
            player.sendMessage(prefix + "§a您有 §e" + count + " §a个离线奖励待领取");
            player.sendMessage(prefix + "§7使用 §f/tr offline list §7查看详情");
            player.sendMessage(prefix + "§7使用 §f/tr offline claim §7领取下一个奖励");
            player.sendMessage(prefix + "§7使用 §f/tr offline claim all §7领取所有奖励");
        }
        
        return true;
    }
    
    /**
     * 显示离线奖励详细列表
     */
    private boolean showOfflineRewardList(Player player) {
        String prefix = plugin.getConfigManager().getPrefix();
        var rewards = plugin.getOfflineRewardManager().getOfflineRewardDetails(player.getUniqueId());
        
        if (rewards.isEmpty()) {
            player.sendMessage(prefix + "§7您当前没有待领取的离线奖励");
            return true;
        }
        
        player.sendMessage(prefix + "§a离线奖励列表：");
        for (int i = 0; i < rewards.size(); i++) {
            var reward = rewards.get(i);
            String time = new java.text.SimpleDateFormat("MM-dd HH:mm").format(new java.util.Date(reward.getTimestamp()));
            player.sendMessage("§7" + (i + 1) + ". §e" + reward.getPlanName() + " §7(" + time + ")");
        }
        
        player.sendMessage(prefix + "§7使用 §f/tr offline claim §7领取下一个奖励");
        
        return true;
    }
    
    /**
     * 领取下一个离线奖励
     */
    private boolean claimNextOfflineReward(Player player) {
        String prefix = plugin.getConfigManager().getPrefix();
        var rewards = plugin.getOfflineRewardManager().getOfflineRewardDetails(player.getUniqueId());
        
        if (rewards.isEmpty()) {
            player.sendMessage(prefix + "§7您当前没有待领取的离线奖励");
            return true;
        }
        
        // 领取最早的奖励
        var reward = rewards.get(0);
        RewardPlan plan = plugin.getRewardManager().getRewardPlan(reward.getPlanId());
        
        if (plan != null) {
            plugin.getRewardManager().giveReward(player, plan);
            plugin.getOfflineRewardManager().removeOfflineReward(player.getUniqueId(), reward.getPlanId(), reward.getTimestamp());
            
            String time = new java.text.SimpleDateFormat("MM-dd HH:mm").format(new java.util.Date(reward.getTimestamp()));
            player.sendMessage(prefix + "§a已领取离线奖励: §e" + reward.getPlanName() + " §7(" + time + ")");
            
            int remaining = plugin.getOfflineRewardManager().getOfflineRewardCount(player.getUniqueId());
            if (remaining > 0) {
                player.sendMessage(prefix + "§7还有 §e" + remaining + " §7个离线奖励待领取");
            }
        } else {
            player.sendMessage(prefix + "§c奖励计划不存在，已自动清理此记录");
            plugin.getOfflineRewardManager().removeOfflineReward(player.getUniqueId(), reward.getPlanId(), reward.getTimestamp());
        }
        
        return true;
    }
    
    /**
     * 领取所有离线奖励
     */
    private boolean claimAllOfflineRewards(Player player) {
        String prefix = plugin.getConfigManager().getPrefix();
        var rewards = plugin.getOfflineRewardManager().getOfflineRewardDetails(player.getUniqueId());
        
        if (rewards.isEmpty()) {
            player.sendMessage(prefix + "§7您当前没有待领取的离线奖励");
            return true;
        }
        
        int successCount = 0;
        for (var reward : rewards) {
            RewardPlan plan = plugin.getRewardManager().getRewardPlan(reward.getPlanId());
            if (plan != null) {
                plugin.getRewardManager().giveReward(player, plan);
                successCount++;
            }
        }
        
        // 清空所有离线奖励
        plugin.getOfflineRewardManager().clearOfflineRewards(player.getUniqueId());
        
        player.sendMessage(prefix + "§a已领取 §e" + successCount + " §a个离线奖励！");
        
        return true;
    }
    
    /**
     * 清空离线奖励（不领取）
     */
    private boolean clearOfflineRewards(Player player) {
        String prefix = plugin.getConfigManager().getPrefix();
        
        if (!player.hasPermission("timedrewards.admin")) {
            player.sendMessage(prefix + "§c您没有权限使用此命令！");
            return true;
        }
        
        int count = plugin.getOfflineRewardManager().getOfflineRewardCount(player.getUniqueId());
        if (count == 0) {
            player.sendMessage(prefix + "§7您当前没有待清理的离线奖励");
            return true;
        }
        
        plugin.getOfflineRewardManager().clearOfflineRewards(player.getUniqueId());
        player.sendMessage(prefix + "§a已清空 §e" + count + " §a个离线奖励记录");
        
        return true;
    }
    
    /**
     * 处理help命令
     */
    private boolean handleHelpCommand(CommandSender sender) {
        String prefix = plugin.getConfigManager().getPrefix();
        
        sender.sendMessage(prefix + "§a命令帮助：");
        sender.sendMessage("§e/tr §7- 打开主界面");
        sender.sendMessage("§e/tr list §7- 列出所有奖励计划");
        sender.sendMessage("§e/tr toggle <计划ID> §7- 启用/禁用奖励计划");
        sender.sendMessage("§e/tr reload §7- 重新加载配置文件");
        
        if (sender instanceof Player && sender.hasPermission("timedrewards.offline")) {
            sender.sendMessage("§e/tr offline §7- 查看离线奖励概览");
            sender.sendMessage("§e/tr offline list §7- 查看离线奖励详情");
            sender.sendMessage("§e/tr offline claim §7- 领取下一个离线奖励");
            sender.sendMessage("§e/tr offline claim all §7- 领取所有离线奖励");
        }
        
        sender.sendMessage("§e/tr help §7- 显示此帮助信息");
        
        return true;
    }
    
    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();
        
        if (args.length == 1) {
            List<String> subCommands = Arrays.asList("list", "toggle", "reload", "offline", "help");
            for (String subCommand : subCommands) {
                if (subCommand.toLowerCase().startsWith(args[0].toLowerCase())) {
                    completions.add(subCommand);
                }
            }
        } else if (args.length == 2) {
            if (args[0].equalsIgnoreCase("toggle")) {
                for (String planId : plugin.getRewardManager().getRewardPlans().keySet()) {
                    if (planId.toLowerCase().startsWith(args[1].toLowerCase())) {
                        completions.add(planId);
                    }
                }
            } else if (args[0].equalsIgnoreCase("offline")) {
                List<String> offlineCommands = Arrays.asList("list", "claim", "clear");
                for (String cmd : offlineCommands) {
                    if (cmd.toLowerCase().startsWith(args[1].toLowerCase())) {
                        completions.add(cmd);
                    }
                }
            }
        } else if (args.length == 3 && args[0].equalsIgnoreCase("offline") && args[1].equalsIgnoreCase("claim")) {
            if ("all".startsWith(args[2].toLowerCase())) {
                completions.add("all");
            }
        }
        
        return completions;
    }
}