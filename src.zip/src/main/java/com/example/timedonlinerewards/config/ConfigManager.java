package com.example.timedonlinerewards.config;

import com.example.timedonlinerewards.TimedOnlineRewards;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;

/**
 * 配置文件管理器
 */
public class ConfigManager {
    
    private final TimedOnlineRewards plugin;
    private FileConfiguration config;
    private FileConfiguration rewardsConfig;
    private File rewardsFile;
    
    public ConfigManager(TimedOnlineRewards plugin) {
        this.plugin = plugin;
    }
    
    public void loadConfigs() {
        // 加载主配置文件
        plugin.saveDefaultConfig();
        config = plugin.getConfig();
        
        // 创建奖励配置文件
        rewardsFile = new File(plugin.getDataFolder(), "rewards.yml");
        if (!rewardsFile.exists()) {
            try {
                boolean created = rewardsFile.createNewFile();
                if (!created) {
                    plugin.getLogger().warning("奖励配置文件可能已存在或创建失败");
                }
            } catch (IOException e) {
                plugin.getLogger().severe("无法创建奖励配置文件: " + e.getMessage());
                return; // 如果无法创建文件，提前返回避免后续错误
            }
        }
        rewardsConfig = YamlConfiguration.loadConfiguration(rewardsFile);
        
        // 创建必要的目录
        File playerDataDir = new File(plugin.getDataFolder(), "playerdata");
        if (!playerDataDir.exists()) {
            boolean created = playerDataDir.mkdirs();
            if (!created) {
                plugin.getLogger().warning("无法创建玩家数据目录: " + playerDataDir.getPath());
            }
        }
        
        File backupsDir = new File(plugin.getDataFolder(), "backups");
        if (!backupsDir.exists()) {
            boolean created = backupsDir.mkdirs();
            if (!created) {
                plugin.getLogger().warning("无法创建备份目录: " + backupsDir.getPath());
            }
        }
    }
    
    public void saveConfigs() {
        try {
            plugin.saveConfig();
            rewardsConfig.save(rewardsFile);
        } catch (IOException e) {
            plugin.getLogger().severe("保存配置文件时出错: " + e.getMessage());
        }
    }
    
    public FileConfiguration getConfig() {
        return config;
    }
    
    public FileConfiguration getRewardsConfig() {
        return rewardsConfig;
    }
    
    public void reloadConfigs() {
        plugin.reloadConfig();
        config = plugin.getConfig();
        rewardsConfig = YamlConfiguration.loadConfiguration(rewardsFile);
    }
    
    public String getPrefix() {
        String prefix = config.getString("prefix", "§6[定时奖励] ");
        return org.bukkit.ChatColor.translateAlternateColorCodes('&', prefix);
    }
    
    public boolean isDebugMode() {
        return config.getBoolean("debug-mode", false);
    }
    
    public String getOfflineHandling() {
        return config.getString("rewards.offline-handling", "keep");
    }
    
    public String getOfflineWelcomeMessage() {
        return config.getString("messages.offline-welcome", "§e欢迎回来！您有 §a%count% §e个离线奖励待领取");
    }
    
    public String getOfflineHintMessage() {
        return config.getString("messages.offline-hint", "§7使用 §f/tr offline §7查看和领取离线奖励");
    }
    
    public String getOfflineDelayMessage() {
        return config.getString("messages.offline-delay", "§e欢迎回来！正在发放您的 §a%count% §e个离线奖励...");
    }
    
    public String getOfflineDelaySuccessMessage() {
        return config.getString("messages.offline-delay-success", "§a已成功发放 §e%count% §a个离线奖励！");
    }
    
    public boolean isAutoBackupEnabled() {
        return config.getBoolean("storage.auto-backup", true);
    }
    
    public int getBackupInterval() {
        return config.getInt("storage.backup-interval", 24);
    }
}