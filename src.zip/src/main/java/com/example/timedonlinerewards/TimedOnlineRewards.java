package com.example.timedonlinerewards;

import com.example.timedonlinerewards.commands.TimedRewardsCommand;
import com.example.timedonlinerewards.config.ConfigManager;
import com.example.timedonlinerewards.gui.GuiManager;
import com.example.timedonlinerewards.listeners.PlayerListener;
import com.example.timedonlinerewards.managers.OfflineRewardManager;
import com.example.timedonlinerewards.managers.RewardManager;
import com.example.timedonlinerewards.managers.ScheduleManager;
import com.example.timedonlinerewards.utils.VaultUtils;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * 定时在线奖励插件主类
 */
public final class TimedOnlineRewards extends JavaPlugin {
    
    private static TimedOnlineRewards instance;
    private ConfigManager configManager;
    private RewardManager rewardManager;
    private ScheduleManager scheduleManager;
    private OfflineRewardManager offlineRewardManager;
    private VaultUtils vaultUtils;
    private GuiManager guiManager;
    
    @Override
    public void onEnable() {
        instance = this;
        
        // 初始化配置管理器
        configManager = new ConfigManager(this);
        configManager.loadConfigs();
        
        // 初始化Vault支持
        vaultUtils = new VaultUtils(this);
        
        // 初始化管理器
        rewardManager = new RewardManager(this);
        scheduleManager = new ScheduleManager(this);
        offlineRewardManager = new OfflineRewardManager(this);
        guiManager = new GuiManager(this);
        
        // 注册命令
        org.bukkit.command.PluginCommand command = getCommand("timedrewards");
        if (command != null) {
            TimedRewardsCommand commandExecutor = new TimedRewardsCommand(this);
            command.setExecutor(commandExecutor);
            command.setTabCompleter(commandExecutor);
            getLogger().info("命令 'timedrewards' 注册成功！");
        } else {
            getLogger().severe("无法注册命令 'timedrewards'，请检查 plugin.yml 配置！");
            getLogger().severe("插件将被禁用以避免功能异常！");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        
        // 注册事件监听器
        getServer().getPluginManager().registerEvents(new PlayerListener(this), this);
        
        // 启动定时任务
        scheduleManager.startScheduler();
        
        getLogger().info("定时在线奖励插件已启用！");
    }
    
    @Override
    public void onDisable() {
        if (scheduleManager != null) {
            scheduleManager.stopScheduler();
        }
        
        if (configManager != null) {
            configManager.saveConfigs();
        }
        
        getLogger().info("定时在线奖励插件已禁用！");
    }
    
    public static TimedOnlineRewards getInstance() {
        return instance;
    }
    
    public ConfigManager getConfigManager() {
        return configManager;
    }
    
    public RewardManager getRewardManager() {
        return rewardManager;
    }
    
    public ScheduleManager getScheduleManager() {
        return scheduleManager;
    }
    
    public OfflineRewardManager getOfflineRewardManager() {
        return offlineRewardManager;
    }
    
    public VaultUtils getVaultUtils() {
        return vaultUtils;
    }
    
    public GuiManager getGuiManager() {
        return guiManager;
    }
}
