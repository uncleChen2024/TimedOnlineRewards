package com.example.timedonlinerewards.listeners;

import com.example.timedonlinerewards.TimedOnlineRewards;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

/**
 * 玩家事件监听器
 */
public class PlayerListener implements Listener {
    
    private final TimedOnlineRewards plugin;
    
    public PlayerListener(TimedOnlineRewards plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        
        // 检查是否有离线期间的奖励需要处理
        // 这里可以扩展为检查玩家数据文件中的离线奖励
        if (plugin.getConfigManager().isDebugMode()) {
            plugin.getLogger().info("玩家 " + player.getName() + " 加入服务器");
        }
        
        // 处理离线奖励
        plugin.getOfflineRewardManager().processOfflineRewards(player);
    }
    
    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        
        if (plugin.getConfigManager().isDebugMode()) {
            plugin.getLogger().info("玩家 " + player.getName() + " 离开服务器");
        }
        
        // 这里可以保存玩家相关的数据
        // 暂时留空，等待后续扩展
    }
}