package com.example.timedonlinerewards.models;

import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

/**
 * 奖励计划数据模型
 */
public class RewardPlan {
    
    private String id;
    private String name;
    private boolean enabled;
    private String customMessage; // 自定义奖励消息
    private TimeSettings timeSettings;
    private RewardContent rewards;
    private long nextExecution;
    
    public RewardPlan(String id, String name) {
        this.id = id;
        this.name = name;
        this.enabled = true;
        this.customMessage = ""; // 默认为空
        this.timeSettings = new TimeSettings();
        this.rewards = new RewardContent();
        this.nextExecution = 0;
    }
    
    // Getters and Setters
    public String getId() {
        return id;
    }
    
    public void setId(String id) {
        this.id = id;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public boolean isEnabled() {
        return enabled;
    }
    
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
    
    public String getCustomMessage() {
        return customMessage;
    }
    
    public void setCustomMessage(String customMessage) {
        this.customMessage = customMessage;
    }
    
    public TimeSettings getTimeSettings() {
        return timeSettings;
    }
    
    public void setTimeSettings(TimeSettings timeSettings) {
        this.timeSettings = timeSettings;
    }
    
    public RewardContent getRewards() {
        return rewards;
    }
    
    public void setRewards(RewardContent rewards) {
        this.rewards = rewards;
    }
    
    public long getNextExecution() {
        return nextExecution;
    }
    
    public void setNextExecution(long nextExecution) {
        this.nextExecution = nextExecution;
    }
    
    /**
     * 时间设置类
     */
    public static class TimeSettings {
        private String type; // daily, weekly, monthly, specific, relative
        private int hour;
        private int minute;
        private int second;
        private int dayOfWeek; // 1-7 (周一到周日)
        private int dayOfMonth; // 1-31
        private long specificTime; // Unix时间戳
        private long relativeTime; // 相对时间（秒）
        
        public TimeSettings() {
            this.type = "daily";
            this.hour = 12;
            this.minute = 0;
            this.second = 0;
            this.dayOfWeek = 1;
            this.dayOfMonth = 1;
            this.specificTime = 0;
            this.relativeTime = 0;
        }
        
        // Getters and Setters
        public String getType() { return type; }
        public void setType(String type) { this.type = type; }
        
        public int getHour() { return hour; }
        public void setHour(int hour) { this.hour = hour; }
        
        public int getMinute() { return minute; }
        public void setMinute(int minute) { this.minute = minute; }
        
        public int getSecond() { return second; }
        public void setSecond(int second) { this.second = second; }
        
        public int getDayOfWeek() { return dayOfWeek; }
        public void setDayOfWeek(int dayOfWeek) { this.dayOfWeek = dayOfWeek; }
        
        public int getDayOfMonth() { return dayOfMonth; }
        public void setDayOfMonth(int dayOfMonth) { this.dayOfMonth = dayOfMonth; }
        
        public long getSpecificTime() { return specificTime; }
        public void setSpecificTime(long specificTime) { this.specificTime = specificTime; }
        
        public long getRelativeTime() { return relativeTime; }
        public void setRelativeTime(long relativeTime) { this.relativeTime = relativeTime; }
    }
    
    /**
     * 奖励内容类
     */
    public static class RewardContent {
        private List<ItemStack> items;
        private double economy;
        private List<String> commands;
        private int experience;
        
        public RewardContent() {
            this.items = new ArrayList<>();
            this.economy = 0.0;
            this.commands = new ArrayList<>();
            this.experience = 0;
        }
        
        // Getters and Setters
        public List<ItemStack> getItems() { return items; }
        public void setItems(List<ItemStack> items) { this.items = items; }
        
        public double getEconomy() { return economy; }
        public void setEconomy(double economy) { this.economy = economy; }
        
        public List<String> getCommands() { return commands; }
        public void setCommands(List<String> commands) { this.commands = commands; }
        
        public int getExperience() { return experience; }
        public void setExperience(int experience) { this.experience = experience; }
    }
}